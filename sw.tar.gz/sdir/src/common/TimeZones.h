// The content of this file is generated with help of macro TZ_UPDATE.

// The content of this file is generated with help of macro TZ_UPDATE.

static const UChar TZSTR_0[] = {'G', 'M', 'T', '\0'};
static const UChar TZSTR_1[] = {'A', 'C', 'T', '\0'};
static const UChar TZSTR_2[] = {'A', 'E', 'T', '\0'};
static const UChar TZSTR_3[] = {'A', 'G', 'T', '\0'};
static const UChar TZSTR_4[] = {'A', 'R', 'T', '\0'};
static const UChar TZSTR_5[] = {'A', 'S', 'T', '\0'};
static const UChar TZSTR_6[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'A', 'b', 'i', 'd', 'j', 'a', 'n', '\0'};
static const UChar TZSTR_7[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'A', 'c', 'c', 'r', 'a', '\0'};
static const UChar TZSTR_8[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'A', 'd', 'd', 'i', 's', '_', 'A', 'b', 'a', 'b', 'a', '\0'};
static const UChar TZSTR_9[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'A', 'l', 'g', 'i', 'e', 'r', 's', '\0'};
static const UChar TZSTR_10[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'A', 's', 'm', 'a', 'r', 'a', '\0'};
static const UChar TZSTR_11[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'A', 's', 'm', 'e', 'r', 'a', '\0'};
static const UChar TZSTR_12[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'a', 'm', 'a', 'k', 'o', '\0'};
static const UChar TZSTR_13[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'a', 'n', 'g', 'u', 'i', '\0'};
static const UChar TZSTR_14[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'a', 'n', 'j', 'u', 'l', '\0'};
static const UChar TZSTR_15[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'i', 's', 's', 'a', 'u', '\0'};
static const UChar TZSTR_16[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'l', 'a', 'n', 't', 'y', 'r', 'e', '\0'};
static const UChar TZSTR_17[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'r', 'a', 'z', 'z', 'a', 'v', 'i', 'l', 'l', 'e', '\0'};
static const UChar TZSTR_18[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'B', 'u', 'j', 'u', 'm', 'b', 'u', 'r', 'a', '\0'};
static const UChar TZSTR_19[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'i', 'r', 'o', '\0'};
static const UChar TZSTR_20[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'C', 'a', 's', 'a', 'b', 'l', 'a', 'n', 'c', 'a', '\0'};
static const UChar TZSTR_21[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'C', 'e', 'u', 't', 'a', '\0'};
static const UChar TZSTR_22[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'C', 'o', 'n', 'a', 'k', 'r', 'y', '\0'};
static const UChar TZSTR_23[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'D', 'a', 'k', 'a', 'r', '\0'};
static const UChar TZSTR_24[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'D', 'a', 'r', '_', 'e', 's', '_', 'S', 'a', 'l', 'a', 'a', 'm', '\0'};
static const UChar TZSTR_25[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'D', 'j', 'i', 'b', 'o', 'u', 't', 'i', '\0'};
static const UChar TZSTR_26[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'D', 'o', 'u', 'a', 'l', 'a', '\0'};
static const UChar TZSTR_27[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'E', 'l', '_', 'A', 'a', 'i', 'u', 'n', '\0'};
static const UChar TZSTR_28[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'F', 'r', 'e', 'e', 't', 'o', 'w', 'n', '\0'};
static const UChar TZSTR_29[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'G', 'a', 'b', 'o', 'r', 'o', 'n', 'e', '\0'};
static const UChar TZSTR_30[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'H', 'a', 'r', 'a', 'r', 'e', '\0'};
static const UChar TZSTR_31[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'J', 'o', 'h', 'a', 'n', 'n', 'e', 's', 'b', 'u', 'r', 'g', '\0'};
static const UChar TZSTR_32[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'J', 'u', 'b', 'a', '\0'};
static const UChar TZSTR_33[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'K', 'a', 'm', 'p', 'a', 'l', 'a', '\0'};
static const UChar TZSTR_34[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'K', 'h', 'a', 'r', 't', 'o', 'u', 'm', '\0'};
static const UChar TZSTR_35[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'K', 'i', 'g', 'a', 'l', 'i', '\0'};
static const UChar TZSTR_36[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'K', 'i', 'n', 's', 'h', 'a', 's', 'a', '\0'};
static const UChar TZSTR_37[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'L', 'a', 'g', 'o', 's', '\0'};
static const UChar TZSTR_38[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'L', 'i', 'b', 'r', 'e', 'v', 'i', 'l', 'l', 'e', '\0'};
static const UChar TZSTR_39[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'L', 'o', 'm', 'e', '\0'};
static const UChar TZSTR_40[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'L', 'u', 'a', 'n', 'd', 'a', '\0'};
static const UChar TZSTR_41[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'L', 'u', 'b', 'u', 'm', 'b', 'a', 's', 'h', 'i', '\0'};
static const UChar TZSTR_42[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'L', 'u', 's', 'a', 'k', 'a', '\0'};
static const UChar TZSTR_43[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'l', 'a', 'b', 'o', '\0'};
static const UChar TZSTR_44[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'p', 'u', 't', 'o', '\0'};
static const UChar TZSTR_45[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'M', 'a', 's', 'e', 'r', 'u', '\0'};
static const UChar TZSTR_46[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'M', 'b', 'a', 'b', 'a', 'n', 'e', '\0'};
static const UChar TZSTR_47[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'g', 'a', 'd', 'i', 's', 'h', 'u', '\0'};
static const UChar TZSTR_48[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'n', 'r', 'o', 'v', 'i', 'a', '\0'};
static const UChar TZSTR_49[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'N', 'a', 'i', 'r', 'o', 'b', 'i', '\0'};
static const UChar TZSTR_50[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'N', 'd', 'j', 'a', 'm', 'e', 'n', 'a', '\0'};
static const UChar TZSTR_51[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'N', 'i', 'a', 'm', 'e', 'y', '\0'};
static const UChar TZSTR_52[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'N', 'o', 'u', 'a', 'k', 'c', 'h', 'o', 't', 't', '\0'};
static const UChar TZSTR_53[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'O', 'u', 'a', 'g', 'a', 'd', 'o', 'u', 'g', 'o', 'u', '\0'};
static const UChar TZSTR_54[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'P', 'o', 'r', 't', 'o', '-', 'N', 'o', 'v', 'o', '\0'};
static const UChar TZSTR_55[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'S', 'a', 'o', '_', 'T', 'o', 'm', 'e', '\0'};
static const UChar TZSTR_56[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'T', 'i', 'm', 'b', 'u', 'k', 't', 'u', '\0'};
static const UChar TZSTR_57[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'T', 'r', 'i', 'p', 'o', 'l', 'i', '\0'};
static const UChar TZSTR_58[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'T', 'u', 'n', 'i', 's', '\0'};
static const UChar TZSTR_59[] = {'A', 'f', 'r', 'i', 'c', 'a', '/', 'W', 'i', 'n', 'd', 'h', 'o', 'e', 'k', '\0'};
static const UChar TZSTR_60[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'd', 'a', 'k', '\0'};
static const UChar TZSTR_61[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'n', 'c', 'h', 'o', 'r', 'a', 'g', 'e', '\0'};
static const UChar TZSTR_62[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'n', 'g', 'u', 'i', 'l', 'l', 'a', '\0'};
static const UChar TZSTR_63[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'n', 't', 'i', 'g', 'u', 'a', '\0'};
static const UChar TZSTR_64[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'a', 'g', 'u', 'a', 'i', 'n', 'a', '\0'};
static const UChar TZSTR_65[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'B', 'u', 'e', 'n', 'o', 's', '_', 'A', 'i', 'r', 'e', 's', '\0'};
static const UChar TZSTR_66[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'C', 'a', 't', 'a', 'm', 'a', 'r', 'c', 'a', '\0'};
static const UChar TZSTR_67[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'C', 'o', 'm', 'o', 'd', 'R', 'i', 'v', 'a', 'd', 'a', 'v', 'i', 'a', '\0'};
static const UChar TZSTR_68[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'C', 'o', 'r', 'd', 'o', 'b', 'a', '\0'};
static const UChar TZSTR_69[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'J', 'u', 'j', 'u', 'y', '\0'};
static const UChar TZSTR_70[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'L', 'a', '_', 'R', 'i', 'o', 'j', 'a', '\0'};
static const UChar TZSTR_71[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'M', 'e', 'n', 'd', 'o', 'z', 'a', '\0'};
static const UChar TZSTR_72[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'R', 'i', 'o', '_', 'G', 'a', 'l', 'l', 'e', 'g', 'o', 's', '\0'};
static const UChar TZSTR_73[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'S', 'a', 'l', 't', 'a', '\0'};
static const UChar TZSTR_74[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'S', 'a', 'n', '_', 'J', 'u', 'a', 'n', '\0'};
static const UChar TZSTR_75[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'S', 'a', 'n', '_', 'L', 'u', 'i', 's', '\0'};
static const UChar TZSTR_76[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'T', 'u', 'c', 'u', 'm', 'a', 'n', '\0'};
static const UChar TZSTR_77[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'g', 'e', 'n', 't', 'i', 'n', 'a', '/', 'U', 's', 'h', 'u', 'a', 'i', 'a', '\0'};
static const UChar TZSTR_78[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 'r', 'u', 'b', 'a', '\0'};
static const UChar TZSTR_79[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 's', 'u', 'n', 'c', 'i', 'o', 'n', '\0'};
static const UChar TZSTR_80[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 't', 'i', 'k', 'o', 'k', 'a', 'n', '\0'};
static const UChar TZSTR_81[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'A', 't', 'k', 'a', '\0'};
static const UChar TZSTR_82[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'a', 'h', 'i', 'a', '\0'};
static const UChar TZSTR_83[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'a', 'h', 'i', 'a', '_', 'B', 'a', 'n', 'd', 'e', 'r', 'a', 's', '\0'};
static const UChar TZSTR_84[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'a', 'r', 'b', 'a', 'd', 'o', 's', '\0'};
static const UChar TZSTR_85[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'e', 'l', 'e', 'm', '\0'};
static const UChar TZSTR_86[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'e', 'l', 'i', 'z', 'e', '\0'};
static const UChar TZSTR_87[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'l', 'a', 'n', 'c', '-', 'S', 'a', 'b', 'l', 'o', 'n', '\0'};
static const UChar TZSTR_88[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'o', 'a', '_', 'V', 'i', 's', 't', 'a', '\0'};
static const UChar TZSTR_89[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'o', 'g', 'o', 't', 'a', '\0'};
static const UChar TZSTR_90[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'o', 'i', 's', 'e', '\0'};
static const UChar TZSTR_91[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'B', 'u', 'e', 'n', 'o', 's', '_', 'A', 'i', 'r', 'e', 's', '\0'};
static const UChar TZSTR_92[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'm', 'b', 'r', 'i', 'd', 'g', 'e', '_', 'B', 'a', 'y', '\0'};
static const UChar TZSTR_93[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'm', 'p', 'o', '_', 'G', 'r', 'a', 'n', 'd', 'e', '\0'};
static const UChar TZSTR_94[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'n', 'c', 'u', 'n', '\0'};
static const UChar TZSTR_95[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'r', 'a', 'c', 'a', 's', '\0'};
static const UChar TZSTR_96[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 't', 'a', 'm', 'a', 'r', 'c', 'a', '\0'};
static const UChar TZSTR_97[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'y', 'e', 'n', 'n', 'e', '\0'};
static const UChar TZSTR_98[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'a', 'y', 'm', 'a', 'n', '\0'};
static const UChar TZSTR_99[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'h', 'i', 'c', 'a', 'g', 'o', '\0'};
static const UChar TZSTR_100[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'h', 'i', 'h', 'u', 'a', 'h', 'u', 'a', '\0'};
static const UChar TZSTR_101[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'o', 'r', 'a', 'l', '_', 'H', 'a', 'r', 'b', 'o', 'u', 'r', '\0'};
static const UChar TZSTR_102[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'o', 'r', 'd', 'o', 'b', 'a', '\0'};
static const UChar TZSTR_103[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'o', 's', 't', 'a', '_', 'R', 'i', 'c', 'a', '\0'};
static const UChar TZSTR_104[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'r', 'e', 's', 't', 'o', 'n', '\0'};
static const UChar TZSTR_105[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'u', 'i', 'a', 'b', 'a', '\0'};
static const UChar TZSTR_106[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'C', 'u', 'r', 'a', 'c', 'a', 'o', '\0'};
static const UChar TZSTR_107[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'D', 'a', 'n', 'm', 'a', 'r', 'k', 's', 'h', 'a', 'v', 'n', '\0'};
static const UChar TZSTR_108[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'D', 'a', 'w', 's', 'o', 'n', '\0'};
static const UChar TZSTR_109[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'D', 'a', 'w', 's', 'o', 'n', '_', 'C', 'r', 'e', 'e', 'k', '\0'};
static const UChar TZSTR_110[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'D', 'e', 'n', 'v', 'e', 'r', '\0'};
static const UChar TZSTR_111[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'D', 'e', 't', 'r', 'o', 'i', 't', '\0'};
static const UChar TZSTR_112[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'D', 'o', 'm', 'i', 'n', 'i', 'c', 'a', '\0'};
static const UChar TZSTR_113[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'E', 'd', 'm', 'o', 'n', 't', 'o', 'n', '\0'};
static const UChar TZSTR_114[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'E', 'i', 'r', 'u', 'n', 'e', 'p', 'e', '\0'};
static const UChar TZSTR_115[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'E', 'l', '_', 'S', 'a', 'l', 'v', 'a', 'd', 'o', 'r', '\0'};
static const UChar TZSTR_116[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'E', 'n', 's', 'e', 'n', 'a', 'd', 'a', '\0'};
static const UChar TZSTR_117[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'F', 'o', 'r', 't', '_', 'N', 'e', 'l', 's', 'o', 'n', '\0'};
static const UChar TZSTR_118[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'F', 'o', 'r', 't', '_', 'W', 'a', 'y', 'n', 'e', '\0'};
static const UChar TZSTR_119[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'F', 'o', 'r', 't', 'a', 'l', 'e', 'z', 'a', '\0'};
static const UChar TZSTR_120[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'l', 'a', 'c', 'e', '_', 'B', 'a', 'y', '\0'};
static const UChar TZSTR_121[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'o', 'd', 't', 'h', 'a', 'b', '\0'};
static const UChar TZSTR_122[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'o', 'o', 's', 'e', '_', 'B', 'a', 'y', '\0'};
static const UChar TZSTR_123[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'r', 'a', 'n', 'd', '_', 'T', 'u', 'r', 'k', '\0'};
static const UChar TZSTR_124[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'r', 'e', 'n', 'a', 'd', 'a', '\0'};
static const UChar TZSTR_125[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'u', 'a', 'd', 'e', 'l', 'o', 'u', 'p', 'e', '\0'};
static const UChar TZSTR_126[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'u', 'a', 't', 'e', 'm', 'a', 'l', 'a', '\0'};
static const UChar TZSTR_127[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'u', 'a', 'y', 'a', 'q', 'u', 'i', 'l', '\0'};
static const UChar TZSTR_128[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'G', 'u', 'y', 'a', 'n', 'a', '\0'};
static const UChar TZSTR_129[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'H', 'a', 'l', 'i', 'f', 'a', 'x', '\0'};
static const UChar TZSTR_130[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'H', 'a', 'v', 'a', 'n', 'a', '\0'};
static const UChar TZSTR_131[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'H', 'e', 'r', 'm', 'o', 's', 'i', 'l', 'l', 'o', '\0'};
static const UChar TZSTR_132[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', 'p', 'o', 'l', 'i', 's', '\0'};
static const UChar TZSTR_133[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'K', 'n', 'o', 'x', '\0'};
static const UChar TZSTR_134[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'M', 'a', 'r', 'e', 'n', 'g', 'o', '\0'};
static const UChar TZSTR_135[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'P', 'e', 't', 'e', 'r', 's', 'b', 'u', 'r', 'g', '\0'};
static const UChar TZSTR_136[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'T', 'e', 'l', 'l', '_', 'C', 'i', 't', 'y', '\0'};
static const UChar TZSTR_137[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'V', 'e', 'v', 'a', 'y', '\0'};
static const UChar TZSTR_138[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'V', 'i', 'n', 'c', 'e', 'n', 'n', 'e', 's', '\0'};
static const UChar TZSTR_139[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '/', 'W', 'i', 'n', 'a', 'm', 'a', 'c', '\0'};
static const UChar TZSTR_140[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', 'p', 'o', 'l', 'i', 's', '\0'};
static const UChar TZSTR_141[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'n', 'u', 'v', 'i', 'k', '\0'};
static const UChar TZSTR_142[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'I', 'q', 'a', 'l', 'u', 'i', 't', '\0'};
static const UChar TZSTR_143[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'J', 'a', 'm', 'a', 'i', 'c', 'a', '\0'};
static const UChar TZSTR_144[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'J', 'u', 'j', 'u', 'y', '\0'};
static const UChar TZSTR_145[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'J', 'u', 'n', 'e', 'a', 'u', '\0'};
static const UChar TZSTR_146[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'K', 'e', 'n', 't', 'u', 'c', 'k', 'y', '/', 'L', 'o', 'u', 'i', 's', 'v', 'i', 'l', 'l', 'e', '\0'};
static const UChar TZSTR_147[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'K', 'e', 'n', 't', 'u', 'c', 'k', 'y', '/', 'M', 'o', 'n', 't', 'i', 'c', 'e', 'l', 'l', 'o', '\0'};
static const UChar TZSTR_148[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'K', 'n', 'o', 'x', '_', 'I', 'N', '\0'};
static const UChar TZSTR_149[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'K', 'r', 'a', 'l', 'e', 'n', 'd', 'i', 'j', 'k', '\0'};
static const UChar TZSTR_150[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'L', 'a', '_', 'P', 'a', 'z', '\0'};
static const UChar TZSTR_151[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'L', 'i', 'm', 'a', '\0'};
static const UChar TZSTR_152[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'L', 'o', 's', '_', 'A', 'n', 'g', 'e', 'l', 'e', 's', '\0'};
static const UChar TZSTR_153[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'L', 'o', 'u', 'i', 's', 'v', 'i', 'l', 'l', 'e', '\0'};
static const UChar TZSTR_154[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'L', 'o', 'w', 'e', 'r', '_', 'P', 'r', 'i', 'n', 'c', 'e', 's', '\0'};
static const UChar TZSTR_155[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'c', 'e', 'i', 'o', '\0'};
static const UChar TZSTR_156[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'n', 'a', 'g', 'u', 'a', '\0'};
static const UChar TZSTR_157[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'n', 'a', 'u', 's', '\0'};
static const UChar TZSTR_158[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'r', 'i', 'g', 'o', 't', '\0'};
static const UChar TZSTR_159[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'r', 't', 'i', 'n', 'i', 'q', 'u', 'e', '\0'};
static const UChar TZSTR_160[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 't', 'a', 'm', 'o', 'r', 'o', 's', '\0'};
static const UChar TZSTR_161[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'a', 'z', 'a', 't', 'l', 'a', 'n', '\0'};
static const UChar TZSTR_162[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'e', 'n', 'd', 'o', 'z', 'a', '\0'};
static const UChar TZSTR_163[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'e', 'n', 'o', 'm', 'i', 'n', 'e', 'e', '\0'};
static const UChar TZSTR_164[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'e', 'r', 'i', 'd', 'a', '\0'};
static const UChar TZSTR_165[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'e', 't', 'l', 'a', 'k', 'a', 't', 'l', 'a', '\0'};
static const UChar TZSTR_166[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'e', 'x', 'i', 'c', 'o', '_', 'C', 'i', 't', 'y', '\0'};
static const UChar TZSTR_167[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'i', 'q', 'u', 'e', 'l', 'o', 'n', '\0'};
static const UChar TZSTR_168[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'n', 'c', 't', 'o', 'n', '\0'};
static const UChar TZSTR_169[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'n', 't', 'e', 'r', 'r', 'e', 'y', '\0'};
static const UChar TZSTR_170[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'n', 't', 'e', 'v', 'i', 'd', 'e', 'o', '\0'};
static const UChar TZSTR_171[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'n', 't', 'r', 'e', 'a', 'l', '\0'};
static const UChar TZSTR_172[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'M', 'o', 'n', 't', 's', 'e', 'r', 'r', 'a', 't', '\0'};
static const UChar TZSTR_173[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'a', 's', 's', 'a', 'u', '\0'};
static const UChar TZSTR_174[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'e', 'w', '_', 'Y', 'o', 'r', 'k', '\0'};
static const UChar TZSTR_175[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'i', 'p', 'i', 'g', 'o', 'n', '\0'};
static const UChar TZSTR_176[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'o', 'm', 'e', '\0'};
static const UChar TZSTR_177[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'o', 'r', 'o', 'n', 'h', 'a', '\0'};
static const UChar TZSTR_178[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'o', 'r', 't', 'h', '_', 'D', 'a', 'k', 'o', 't', 'a', '/', 'B', 'e', 'u', 'l', 'a', 'h', '\0'};
static const UChar TZSTR_179[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'o', 'r', 't', 'h', '_', 'D', 'a', 'k', 'o', 't', 'a', '/', 'C', 'e', 'n', 't', 'e', 'r', '\0'};
static const UChar TZSTR_180[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'N', 'o', 'r', 't', 'h', '_', 'D', 'a', 'k', 'o', 't', 'a', '/', 'N', 'e', 'w', '_', 'S', 'a', 'l', 'e', 'm', '\0'};
static const UChar TZSTR_181[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'O', 'j', 'i', 'n', 'a', 'g', 'a', '\0'};
static const UChar TZSTR_182[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'a', 'n', 'a', 'm', 'a', '\0'};
static const UChar TZSTR_183[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'a', 'n', 'g', 'n', 'i', 'r', 't', 'u', 'n', 'g', '\0'};
static const UChar TZSTR_184[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'a', 'r', 'a', 'm', 'a', 'r', 'i', 'b', 'o', '\0'};
static const UChar TZSTR_185[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'h', 'o', 'e', 'n', 'i', 'x', '\0'};
static const UChar TZSTR_186[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'o', 'r', 't', '-', 'a', 'u', '-', 'P', 'r', 'i', 'n', 'c', 'e', '\0'};
static const UChar TZSTR_187[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'o', 'r', 't', '_', 'o', 'f', '_', 'S', 'p', 'a', 'i', 'n', '\0'};
static const UChar TZSTR_188[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'o', 'r', 't', 'o', '_', 'A', 'c', 'r', 'e', '\0'};
static const UChar TZSTR_189[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'o', 'r', 't', 'o', '_', 'V', 'e', 'l', 'h', 'o', '\0'};
static const UChar TZSTR_190[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'u', 'e', 'r', 't', 'o', '_', 'R', 'i', 'c', 'o', '\0'};
static const UChar TZSTR_191[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'P', 'u', 'n', 't', 'a', '_', 'A', 'r', 'e', 'n', 'a', 's', '\0'};
static const UChar TZSTR_192[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'a', 'i', 'n', 'y', '_', 'R', 'i', 'v', 'e', 'r', '\0'};
static const UChar TZSTR_193[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'a', 'n', 'k', 'i', 'n', '_', 'I', 'n', 'l', 'e', 't', '\0'};
static const UChar TZSTR_194[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'e', 'c', 'i', 'f', 'e', '\0'};
static const UChar TZSTR_195[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'e', 'g', 'i', 'n', 'a', '\0'};
static const UChar TZSTR_196[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'e', 's', 'o', 'l', 'u', 't', 'e', '\0'};
static const UChar TZSTR_197[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'i', 'o', '_', 'B', 'r', 'a', 'n', 'c', 'o', '\0'};
static const UChar TZSTR_198[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'R', 'o', 's', 'a', 'r', 'i', 'o', '\0'};
static const UChar TZSTR_199[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'a', 'n', 't', 'a', '_', 'I', 's', 'a', 'b', 'e', 'l', '\0'};
static const UChar TZSTR_200[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'a', 'n', 't', 'a', 'r', 'e', 'm', '\0'};
static const UChar TZSTR_201[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'a', 'n', 't', 'i', 'a', 'g', 'o', '\0'};
static const UChar TZSTR_202[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'a', 'n', 't', 'o', '_', 'D', 'o', 'm', 'i', 'n', 'g', 'o', '\0'};
static const UChar TZSTR_203[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'a', 'o', '_', 'P', 'a', 'u', 'l', 'o', '\0'};
static const UChar TZSTR_204[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'c', 'o', 'r', 'e', 's', 'b', 'y', 's', 'u', 'n', 'd', '\0'};
static const UChar TZSTR_205[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'h', 'i', 'p', 'r', 'o', 'c', 'k', '\0'};
static const UChar TZSTR_206[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'i', 't', 'k', 'a', '\0'};
static const UChar TZSTR_207[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 't', '_', 'B', 'a', 'r', 't', 'h', 'e', 'l', 'e', 'm', 'y', '\0'};
static const UChar TZSTR_208[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 't', '_', 'J', 'o', 'h', 'n', 's', '\0'};
static const UChar TZSTR_209[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 't', '_', 'K', 'i', 't', 't', 's', '\0'};
static const UChar TZSTR_210[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 't', '_', 'L', 'u', 'c', 'i', 'a', '\0'};
static const UChar TZSTR_211[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 't', '_', 'T', 'h', 'o', 'm', 'a', 's', '\0'};
static const UChar TZSTR_212[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 't', '_', 'V', 'i', 'n', 'c', 'e', 'n', 't', '\0'};
static const UChar TZSTR_213[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'S', 'w', 'i', 'f', 't', '_', 'C', 'u', 'r', 'r', 'e', 'n', 't', '\0'};
static const UChar TZSTR_214[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'T', 'e', 'g', 'u', 'c', 'i', 'g', 'a', 'l', 'p', 'a', '\0'};
static const UChar TZSTR_215[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'T', 'h', 'u', 'l', 'e', '\0'};
static const UChar TZSTR_216[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'T', 'h', 'u', 'n', 'd', 'e', 'r', '_', 'B', 'a', 'y', '\0'};
static const UChar TZSTR_217[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'T', 'i', 'j', 'u', 'a', 'n', 'a', '\0'};
static const UChar TZSTR_218[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'T', 'o', 'r', 'o', 'n', 't', 'o', '\0'};
static const UChar TZSTR_219[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'T', 'o', 'r', 't', 'o', 'l', 'a', '\0'};
static const UChar TZSTR_220[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'V', 'a', 'n', 'c', 'o', 'u', 'v', 'e', 'r', '\0'};
static const UChar TZSTR_221[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'V', 'i', 'r', 'g', 'i', 'n', '\0'};
static const UChar TZSTR_222[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'W', 'h', 'i', 't', 'e', 'h', 'o', 'r', 's', 'e', '\0'};
static const UChar TZSTR_223[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'W', 'i', 'n', 'n', 'i', 'p', 'e', 'g', '\0'};
static const UChar TZSTR_224[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'Y', 'a', 'k', 'u', 't', 'a', 't', '\0'};
static const UChar TZSTR_225[] = {'A', 'm', 'e', 'r', 'i', 'c', 'a', '/', 'Y', 'e', 'l', 'l', 'o', 'w', 'k', 'n', 'i', 'f', 'e', '\0'};
static const UChar TZSTR_226[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'C', 'a', 's', 'e', 'y', '\0'};
static const UChar TZSTR_227[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'D', 'a', 'v', 'i', 's', '\0'};
static const UChar TZSTR_228[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'D', 'u', 'm', 'o', 'n', 't', 'D', 'U', 'r', 'v', 'i', 'l', 'l', 'e', '\0'};
static const UChar TZSTR_229[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'M', 'a', 'c', 'q', 'u', 'a', 'r', 'i', 'e', '\0'};
static const UChar TZSTR_230[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'M', 'a', 'w', 's', 'o', 'n', '\0'};
static const UChar TZSTR_231[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'M', 'c', 'M', 'u', 'r', 'd', 'o', '\0'};
static const UChar TZSTR_232[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'P', 'a', 'l', 'm', 'e', 'r', '\0'};
static const UChar TZSTR_233[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'R', 'o', 't', 'h', 'e', 'r', 'a', '\0'};
static const UChar TZSTR_234[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'S', 'o', 'u', 't', 'h', '_', 'P', 'o', 'l', 'e', '\0'};
static const UChar TZSTR_235[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'S', 'y', 'o', 'w', 'a', '\0'};
static const UChar TZSTR_236[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'T', 'r', 'o', 'l', 'l', '\0'};
static const UChar TZSTR_237[] = {'A', 'n', 't', 'a', 'r', 'c', 't', 'i', 'c', 'a', '/', 'V', 'o', 's', 't', 'o', 'k', '\0'};
static const UChar TZSTR_238[] = {'A', 'r', 'c', 't', 'i', 'c', '/', 'L', 'o', 'n', 'g', 'y', 'e', 'a', 'r', 'b', 'y', 'e', 'n', '\0'};
static const UChar TZSTR_239[] = {'A', 's', 'i', 'a', '/', 'A', 'd', 'e', 'n', '\0'};
static const UChar TZSTR_240[] = {'A', 's', 'i', 'a', '/', 'A', 'l', 'm', 'a', 't', 'y', '\0'};
static const UChar TZSTR_241[] = {'A', 's', 'i', 'a', '/', 'A', 'm', 'm', 'a', 'n', '\0'};
static const UChar TZSTR_242[] = {'A', 's', 'i', 'a', '/', 'A', 'n', 'a', 'd', 'y', 'r', '\0'};
static const UChar TZSTR_243[] = {'A', 's', 'i', 'a', '/', 'A', 'q', 't', 'a', 'u', '\0'};
static const UChar TZSTR_244[] = {'A', 's', 'i', 'a', '/', 'A', 'q', 't', 'o', 'b', 'e', '\0'};
static const UChar TZSTR_245[] = {'A', 's', 'i', 'a', '/', 'A', 's', 'h', 'g', 'a', 'b', 'a', 't', '\0'};
static const UChar TZSTR_246[] = {'A', 's', 'i', 'a', '/', 'A', 's', 'h', 'k', 'h', 'a', 'b', 'a', 'd', '\0'};
static const UChar TZSTR_247[] = {'A', 's', 'i', 'a', '/', 'A', 't', 'y', 'r', 'a', 'u', '\0'};
static const UChar TZSTR_248[] = {'A', 's', 'i', 'a', '/', 'B', 'a', 'g', 'h', 'd', 'a', 'd', '\0'};
static const UChar TZSTR_249[] = {'A', 's', 'i', 'a', '/', 'B', 'a', 'h', 'r', 'a', 'i', 'n', '\0'};
static const UChar TZSTR_250[] = {'A', 's', 'i', 'a', '/', 'B', 'a', 'k', 'u', '\0'};
static const UChar TZSTR_251[] = {'A', 's', 'i', 'a', '/', 'B', 'a', 'n', 'g', 'k', 'o', 'k', '\0'};
static const UChar TZSTR_252[] = {'A', 's', 'i', 'a', '/', 'B', 'a', 'r', 'n', 'a', 'u', 'l', '\0'};
static const UChar TZSTR_253[] = {'A', 's', 'i', 'a', '/', 'B', 'e', 'i', 'r', 'u', 't', '\0'};
static const UChar TZSTR_254[] = {'A', 's', 'i', 'a', '/', 'B', 'i', 's', 'h', 'k', 'e', 'k', '\0'};
static const UChar TZSTR_255[] = {'A', 's', 'i', 'a', '/', 'B', 'r', 'u', 'n', 'e', 'i', '\0'};
static const UChar TZSTR_256[] = {'A', 's', 'i', 'a', '/', 'C', 'a', 'l', 'c', 'u', 't', 't', 'a', '\0'};
static const UChar TZSTR_257[] = {'A', 's', 'i', 'a', '/', 'C', 'h', 'i', 't', 'a', '\0'};
static const UChar TZSTR_258[] = {'A', 's', 'i', 'a', '/', 'C', 'h', 'o', 'i', 'b', 'a', 'l', 's', 'a', 'n', '\0'};
static const UChar TZSTR_259[] = {'A', 's', 'i', 'a', '/', 'C', 'h', 'o', 'n', 'g', 'q', 'i', 'n', 'g', '\0'};
static const UChar TZSTR_260[] = {'A', 's', 'i', 'a', '/', 'C', 'h', 'u', 'n', 'g', 'k', 'i', 'n', 'g', '\0'};
static const UChar TZSTR_261[] = {'A', 's', 'i', 'a', '/', 'C', 'o', 'l', 'o', 'm', 'b', 'o', '\0'};
static const UChar TZSTR_262[] = {'A', 's', 'i', 'a', '/', 'D', 'a', 'c', 'c', 'a', '\0'};
static const UChar TZSTR_263[] = {'A', 's', 'i', 'a', '/', 'D', 'a', 'm', 'a', 's', 'c', 'u', 's', '\0'};
static const UChar TZSTR_264[] = {'A', 's', 'i', 'a', '/', 'D', 'h', 'a', 'k', 'a', '\0'};
static const UChar TZSTR_265[] = {'A', 's', 'i', 'a', '/', 'D', 'i', 'l', 'i', '\0'};
static const UChar TZSTR_266[] = {'A', 's', 'i', 'a', '/', 'D', 'u', 'b', 'a', 'i', '\0'};
static const UChar TZSTR_267[] = {'A', 's', 'i', 'a', '/', 'D', 'u', 's', 'h', 'a', 'n', 'b', 'e', '\0'};
static const UChar TZSTR_268[] = {'A', 's', 'i', 'a', '/', 'F', 'a', 'm', 'a', 'g', 'u', 's', 't', 'a', '\0'};
static const UChar TZSTR_269[] = {'A', 's', 'i', 'a', '/', 'G', 'a', 'z', 'a', '\0'};
static const UChar TZSTR_270[] = {'A', 's', 'i', 'a', '/', 'H', 'a', 'r', 'b', 'i', 'n', '\0'};
static const UChar TZSTR_271[] = {'A', 's', 'i', 'a', '/', 'H', 'e', 'b', 'r', 'o', 'n', '\0'};
static const UChar TZSTR_272[] = {'A', 's', 'i', 'a', '/', 'H', 'o', '_', 'C', 'h', 'i', '_', 'M', 'i', 'n', 'h', '\0'};
static const UChar TZSTR_273[] = {'A', 's', 'i', 'a', '/', 'H', 'o', 'n', 'g', '_', 'K', 'o', 'n', 'g', '\0'};
static const UChar TZSTR_274[] = {'A', 's', 'i', 'a', '/', 'H', 'o', 'v', 'd', '\0'};
static const UChar TZSTR_275[] = {'A', 's', 'i', 'a', '/', 'I', 'r', 'k', 'u', 't', 's', 'k', '\0'};
static const UChar TZSTR_276[] = {'A', 's', 'i', 'a', '/', 'I', 's', 't', 'a', 'n', 'b', 'u', 'l', '\0'};
static const UChar TZSTR_277[] = {'A', 's', 'i', 'a', '/', 'J', 'a', 'k', 'a', 'r', 't', 'a', '\0'};
static const UChar TZSTR_278[] = {'A', 's', 'i', 'a', '/', 'J', 'a', 'y', 'a', 'p', 'u', 'r', 'a', '\0'};
static const UChar TZSTR_279[] = {'A', 's', 'i', 'a', '/', 'J', 'e', 'r', 'u', 's', 'a', 'l', 'e', 'm', '\0'};
static const UChar TZSTR_280[] = {'A', 's', 'i', 'a', '/', 'K', 'a', 'b', 'u', 'l', '\0'};
static const UChar TZSTR_281[] = {'A', 's', 'i', 'a', '/', 'K', 'a', 'm', 'c', 'h', 'a', 't', 'k', 'a', '\0'};
static const UChar TZSTR_282[] = {'A', 's', 'i', 'a', '/', 'K', 'a', 'r', 'a', 'c', 'h', 'i', '\0'};
static const UChar TZSTR_283[] = {'A', 's', 'i', 'a', '/', 'K', 'a', 's', 'h', 'g', 'a', 'r', '\0'};
static const UChar TZSTR_284[] = {'A', 's', 'i', 'a', '/', 'K', 'a', 't', 'h', 'm', 'a', 'n', 'd', 'u', '\0'};
static const UChar TZSTR_285[] = {'A', 's', 'i', 'a', '/', 'K', 'a', 't', 'm', 'a', 'n', 'd', 'u', '\0'};
static const UChar TZSTR_286[] = {'A', 's', 'i', 'a', '/', 'K', 'h', 'a', 'n', 'd', 'y', 'g', 'a', '\0'};
static const UChar TZSTR_287[] = {'A', 's', 'i', 'a', '/', 'K', 'o', 'l', 'k', 'a', 't', 'a', '\0'};
static const UChar TZSTR_288[] = {'A', 's', 'i', 'a', '/', 'K', 'r', 'a', 's', 'n', 'o', 'y', 'a', 'r', 's', 'k', '\0'};
static const UChar TZSTR_289[] = {'A', 's', 'i', 'a', '/', 'K', 'u', 'a', 'l', 'a', '_', 'L', 'u', 'm', 'p', 'u', 'r', '\0'};
static const UChar TZSTR_290[] = {'A', 's', 'i', 'a', '/', 'K', 'u', 'c', 'h', 'i', 'n', 'g', '\0'};
static const UChar TZSTR_291[] = {'A', 's', 'i', 'a', '/', 'K', 'u', 'w', 'a', 'i', 't', '\0'};
static const UChar TZSTR_292[] = {'A', 's', 'i', 'a', '/', 'M', 'a', 'c', 'a', 'o', '\0'};
static const UChar TZSTR_293[] = {'A', 's', 'i', 'a', '/', 'M', 'a', 'c', 'a', 'u', '\0'};
static const UChar TZSTR_294[] = {'A', 's', 'i', 'a', '/', 'M', 'a', 'g', 'a', 'd', 'a', 'n', '\0'};
static const UChar TZSTR_295[] = {'A', 's', 'i', 'a', '/', 'M', 'a', 'k', 'a', 's', 's', 'a', 'r', '\0'};
static const UChar TZSTR_296[] = {'A', 's', 'i', 'a', '/', 'M', 'a', 'n', 'i', 'l', 'a', '\0'};
static const UChar TZSTR_297[] = {'A', 's', 'i', 'a', '/', 'M', 'u', 's', 'c', 'a', 't', '\0'};
static const UChar TZSTR_298[] = {'A', 's', 'i', 'a', '/', 'N', 'i', 'c', 'o', 's', 'i', 'a', '\0'};
static const UChar TZSTR_299[] = {'A', 's', 'i', 'a', '/', 'N', 'o', 'v', 'o', 'k', 'u', 'z', 'n', 'e', 't', 's', 'k', '\0'};
static const UChar TZSTR_300[] = {'A', 's', 'i', 'a', '/', 'N', 'o', 'v', 'o', 's', 'i', 'b', 'i', 'r', 's', 'k', '\0'};
static const UChar TZSTR_301[] = {'A', 's', 'i', 'a', '/', 'O', 'm', 's', 'k', '\0'};
static const UChar TZSTR_302[] = {'A', 's', 'i', 'a', '/', 'O', 'r', 'a', 'l', '\0'};
static const UChar TZSTR_303[] = {'A', 's', 'i', 'a', '/', 'P', 'h', 'n', 'o', 'm', '_', 'P', 'e', 'n', 'h', '\0'};
static const UChar TZSTR_304[] = {'A', 's', 'i', 'a', '/', 'P', 'o', 'n', 't', 'i', 'a', 'n', 'a', 'k', '\0'};
static const UChar TZSTR_305[] = {'A', 's', 'i', 'a', '/', 'P', 'y', 'o', 'n', 'g', 'y', 'a', 'n', 'g', '\0'};
static const UChar TZSTR_306[] = {'A', 's', 'i', 'a', '/', 'Q', 'a', 't', 'a', 'r', '\0'};
static const UChar TZSTR_307[] = {'A', 's', 'i', 'a', '/', 'Q', 'y', 'z', 'y', 'l', 'o', 'r', 'd', 'a', '\0'};
static const UChar TZSTR_308[] = {'A', 's', 'i', 'a', '/', 'R', 'a', 'n', 'g', 'o', 'o', 'n', '\0'};
static const UChar TZSTR_309[] = {'A', 's', 'i', 'a', '/', 'R', 'i', 'y', 'a', 'd', 'h', '\0'};
static const UChar TZSTR_310[] = {'A', 's', 'i', 'a', '/', 'S', 'a', 'i', 'g', 'o', 'n', '\0'};
static const UChar TZSTR_311[] = {'A', 's', 'i', 'a', '/', 'S', 'a', 'k', 'h', 'a', 'l', 'i', 'n', '\0'};
static const UChar TZSTR_312[] = {'A', 's', 'i', 'a', '/', 'S', 'a', 'm', 'a', 'r', 'k', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_313[] = {'A', 's', 'i', 'a', '/', 'S', 'e', 'o', 'u', 'l', '\0'};
static const UChar TZSTR_314[] = {'A', 's', 'i', 'a', '/', 'S', 'h', 'a', 'n', 'g', 'h', 'a', 'i', '\0'};
static const UChar TZSTR_315[] = {'A', 's', 'i', 'a', '/', 'S', 'i', 'n', 'g', 'a', 'p', 'o', 'r', 'e', '\0'};
static const UChar TZSTR_316[] = {'A', 's', 'i', 'a', '/', 'S', 'r', 'e', 'd', 'n', 'e', 'k', 'o', 'l', 'y', 'm', 's', 'k', '\0'};
static const UChar TZSTR_317[] = {'A', 's', 'i', 'a', '/', 'T', 'a', 'i', 'p', 'e', 'i', '\0'};
static const UChar TZSTR_318[] = {'A', 's', 'i', 'a', '/', 'T', 'a', 's', 'h', 'k', 'e', 'n', 't', '\0'};
static const UChar TZSTR_319[] = {'A', 's', 'i', 'a', '/', 'T', 'b', 'i', 'l', 'i', 's', 'i', '\0'};
static const UChar TZSTR_320[] = {'A', 's', 'i', 'a', '/', 'T', 'e', 'h', 'r', 'a', 'n', '\0'};
static const UChar TZSTR_321[] = {'A', 's', 'i', 'a', '/', 'T', 'e', 'l', '_', 'A', 'v', 'i', 'v', '\0'};
static const UChar TZSTR_322[] = {'A', 's', 'i', 'a', '/', 'T', 'h', 'i', 'm', 'b', 'u', '\0'};
static const UChar TZSTR_323[] = {'A', 's', 'i', 'a', '/', 'T', 'h', 'i', 'm', 'p', 'h', 'u', '\0'};
static const UChar TZSTR_324[] = {'A', 's', 'i', 'a', '/', 'T', 'o', 'k', 'y', 'o', '\0'};
static const UChar TZSTR_325[] = {'A', 's', 'i', 'a', '/', 'T', 'o', 'm', 's', 'k', '\0'};
static const UChar TZSTR_326[] = {'A', 's', 'i', 'a', '/', 'U', 'j', 'u', 'n', 'g', '_', 'P', 'a', 'n', 'd', 'a', 'n', 'g', '\0'};
static const UChar TZSTR_327[] = {'A', 's', 'i', 'a', '/', 'U', 'l', 'a', 'a', 'n', 'b', 'a', 'a', 't', 'a', 'r', '\0'};
static const UChar TZSTR_328[] = {'A', 's', 'i', 'a', '/', 'U', 'l', 'a', 'n', '_', 'B', 'a', 't', 'o', 'r', '\0'};
static const UChar TZSTR_329[] = {'A', 's', 'i', 'a', '/', 'U', 'r', 'u', 'm', 'q', 'i', '\0'};
static const UChar TZSTR_330[] = {'A', 's', 'i', 'a', '/', 'U', 's', 't', '-', 'N', 'e', 'r', 'a', '\0'};
static const UChar TZSTR_331[] = {'A', 's', 'i', 'a', '/', 'V', 'i', 'e', 'n', 't', 'i', 'a', 'n', 'e', '\0'};
static const UChar TZSTR_332[] = {'A', 's', 'i', 'a', '/', 'V', 'l', 'a', 'd', 'i', 'v', 'o', 's', 't', 'o', 'k', '\0'};
static const UChar TZSTR_333[] = {'A', 's', 'i', 'a', '/', 'Y', 'a', 'k', 'u', 't', 's', 'k', '\0'};
static const UChar TZSTR_334[] = {'A', 's', 'i', 'a', '/', 'Y', 'a', 'n', 'g', 'o', 'n', '\0'};
static const UChar TZSTR_335[] = {'A', 's', 'i', 'a', '/', 'Y', 'e', 'k', 'a', 't', 'e', 'r', 'i', 'n', 'b', 'u', 'r', 'g', '\0'};
static const UChar TZSTR_336[] = {'A', 's', 'i', 'a', '/', 'Y', 'e', 'r', 'e', 'v', 'a', 'n', '\0'};
static const UChar TZSTR_337[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'A', 'z', 'o', 'r', 'e', 's', '\0'};
static const UChar TZSTR_338[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'B', 'e', 'r', 'm', 'u', 'd', 'a', '\0'};
static const UChar TZSTR_339[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'C', 'a', 'n', 'a', 'r', 'y', '\0'};
static const UChar TZSTR_340[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'C', 'a', 'p', 'e', '_', 'V', 'e', 'r', 'd', 'e', '\0'};
static const UChar TZSTR_341[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'F', 'a', 'e', 'r', 'o', 'e', '\0'};
static const UChar TZSTR_342[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'F', 'a', 'r', 'o', 'e', '\0'};
static const UChar TZSTR_343[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'J', 'a', 'n', '_', 'M', 'a', 'y', 'e', 'n', '\0'};
static const UChar TZSTR_344[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'M', 'a', 'd', 'e', 'i', 'r', 'a', '\0'};
static const UChar TZSTR_345[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'R', 'e', 'y', 'k', 'j', 'a', 'v', 'i', 'k', '\0'};
static const UChar TZSTR_346[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'S', 'o', 'u', 't', 'h', '_', 'G', 'e', 'o', 'r', 'g', 'i', 'a', '\0'};
static const UChar TZSTR_347[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'S', 't', '_', 'H', 'e', 'l', 'e', 'n', 'a', '\0'};
static const UChar TZSTR_348[] = {'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '/', 'S', 't', 'a', 'n', 'l', 'e', 'y', '\0'};
static const UChar TZSTR_349[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'A', 'C', 'T', '\0'};
static const UChar TZSTR_350[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'A', 'd', 'e', 'l', 'a', 'i', 'd', 'e', '\0'};
static const UChar TZSTR_351[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'B', 'r', 'i', 's', 'b', 'a', 'n', 'e', '\0'};
static const UChar TZSTR_352[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'B', 'r', 'o', 'k', 'e', 'n', '_', 'H', 'i', 'l', 'l', '\0'};
static const UChar TZSTR_353[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'C', 'a', 'n', 'b', 'e', 'r', 'r', 'a', '\0'};
static const UChar TZSTR_354[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'C', 'u', 'r', 'r', 'i', 'e', '\0'};
static const UChar TZSTR_355[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'D', 'a', 'r', 'w', 'i', 'n', '\0'};
static const UChar TZSTR_356[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'E', 'u', 'c', 'l', 'a', '\0'};
static const UChar TZSTR_357[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'H', 'o', 'b', 'a', 'r', 't', '\0'};
static const UChar TZSTR_358[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'L', 'H', 'I', '\0'};
static const UChar TZSTR_359[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'L', 'i', 'n', 'd', 'e', 'm', 'a', 'n', '\0'};
static const UChar TZSTR_360[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'L', 'o', 'r', 'd', '_', 'H', 'o', 'w', 'e', '\0'};
static const UChar TZSTR_361[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'M', 'e', 'l', 'b', 'o', 'u', 'r', 'n', 'e', '\0'};
static const UChar TZSTR_362[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'N', 'S', 'W', '\0'};
static const UChar TZSTR_363[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'N', 'o', 'r', 't', 'h', '\0'};
static const UChar TZSTR_364[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'P', 'e', 'r', 't', 'h', '\0'};
static const UChar TZSTR_365[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'Q', 'u', 'e', 'e', 'n', 's', 'l', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_366[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'S', 'o', 'u', 't', 'h', '\0'};
static const UChar TZSTR_367[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'S', 'y', 'd', 'n', 'e', 'y', '\0'};
static const UChar TZSTR_368[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'T', 'a', 's', 'm', 'a', 'n', 'i', 'a', '\0'};
static const UChar TZSTR_369[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'V', 'i', 'c', 't', 'o', 'r', 'i', 'a', '\0'};
static const UChar TZSTR_370[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'W', 'e', 's', 't', '\0'};
static const UChar TZSTR_371[] = {'A', 'u', 's', 't', 'r', 'a', 'l', 'i', 'a', '/', 'Y', 'a', 'n', 'c', 'o', 'w', 'i', 'n', 'n', 'a', '\0'};
static const UChar TZSTR_372[] = {'B', 'E', 'T', '\0'};
static const UChar TZSTR_373[] = {'B', 'S', 'T', '\0'};
static const UChar TZSTR_374[] = {'B', 'r', 'a', 'z', 'i', 'l', '/', 'A', 'c', 'r', 'e', '\0'};
static const UChar TZSTR_375[] = {'B', 'r', 'a', 'z', 'i', 'l', '/', 'D', 'e', 'N', 'o', 'r', 'o', 'n', 'h', 'a', '\0'};
static const UChar TZSTR_376[] = {'B', 'r', 'a', 'z', 'i', 'l', '/', 'E', 'a', 's', 't', '\0'};
static const UChar TZSTR_377[] = {'B', 'r', 'a', 'z', 'i', 'l', '/', 'W', 'e', 's', 't', '\0'};
static const UChar TZSTR_378[] = {'C', 'A', 'T', '\0'};
static const UChar TZSTR_379[] = {'C', 'E', 'T', '\0'};
static const UChar TZSTR_380[] = {'C', 'N', 'T', '\0'};
static const UChar TZSTR_381[] = {'C', 'S', 'T', '\0'};
static const UChar TZSTR_382[] = {'C', 'S', 'T', '6', 'C', 'D', 'T', '\0'};
static const UChar TZSTR_383[] = {'C', 'T', 'T', '\0'};
static const UChar TZSTR_384[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'A', 't', 'l', 'a', 'n', 't', 'i', 'c', '\0'};
static const UChar TZSTR_385[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'C', 'e', 'n', 't', 'r', 'a', 'l', '\0'};
static const UChar TZSTR_386[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'E', 'a', 's', 't', '-', 'S', 'a', 's', 'k', 'a', 't', 'c', 'h', 'e', 'w', 'a', 'n', '\0'};
static const UChar TZSTR_387[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'E', 'a', 's', 't', 'e', 'r', 'n', '\0'};
static const UChar TZSTR_388[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'M', 'o', 'u', 'n', 't', 'a', 'i', 'n', '\0'};
static const UChar TZSTR_389[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'N', 'e', 'w', 'f', 'o', 'u', 'n', 'd', 'l', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_390[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'P', 'a', 'c', 'i', 'f', 'i', 'c', '\0'};
static const UChar TZSTR_391[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'S', 'a', 's', 'k', 'a', 't', 'c', 'h', 'e', 'w', 'a', 'n', '\0'};
static const UChar TZSTR_392[] = {'C', 'a', 'n', 'a', 'd', 'a', '/', 'Y', 'u', 'k', 'o', 'n', '\0'};
static const UChar TZSTR_393[] = {'C', 'h', 'i', 'l', 'e', '/', 'C', 'o', 'n', 't', 'i', 'n', 'e', 'n', 't', 'a', 'l', '\0'};
static const UChar TZSTR_394[] = {'C', 'h', 'i', 'l', 'e', '/', 'E', 'a', 's', 't', 'e', 'r', 'I', 's', 'l', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_395[] = {'C', 'u', 'b', 'a', '\0'};
static const UChar TZSTR_396[] = {'E', 'A', 'T', '\0'};
static const UChar TZSTR_397[] = {'E', 'C', 'T', '\0'};
static const UChar TZSTR_398[] = {'E', 'E', 'T', '\0'};
static const UChar TZSTR_399[] = {'E', 'S', 'T', '\0'};
static const UChar TZSTR_400[] = {'E', 'S', 'T', '5', 'E', 'D', 'T', '\0'};
static const UChar TZSTR_401[] = {'E', 'g', 'y', 'p', 't', '\0'};
static const UChar TZSTR_402[] = {'E', 'i', 'r', 'e', '\0'};
static const UChar TZSTR_403[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '\0'};
static const UChar TZSTR_404[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '0', '\0'};
static const UChar TZSTR_405[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '1', '\0'};
static const UChar TZSTR_406[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '1', '0', '\0'};
static const UChar TZSTR_407[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '1', '1', '\0'};
static const UChar TZSTR_408[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '1', '2', '\0'};
static const UChar TZSTR_409[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '2', '\0'};
static const UChar TZSTR_410[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '3', '\0'};
static const UChar TZSTR_411[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '4', '\0'};
static const UChar TZSTR_412[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '5', '\0'};
static const UChar TZSTR_413[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '6', '\0'};
static const UChar TZSTR_414[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '7', '\0'};
static const UChar TZSTR_415[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '8', '\0'};
static const UChar TZSTR_416[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '+', '9', '\0'};
static const UChar TZSTR_417[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '0', '\0'};
static const UChar TZSTR_418[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '1', '\0'};
static const UChar TZSTR_419[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '1', '0', '\0'};
static const UChar TZSTR_420[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '1', '1', '\0'};
static const UChar TZSTR_421[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '1', '2', '\0'};
static const UChar TZSTR_422[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '1', '3', '\0'};
static const UChar TZSTR_423[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '1', '4', '\0'};
static const UChar TZSTR_424[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '2', '\0'};
static const UChar TZSTR_425[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '3', '\0'};
static const UChar TZSTR_426[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '4', '\0'};
static const UChar TZSTR_427[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '5', '\0'};
static const UChar TZSTR_428[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '6', '\0'};
static const UChar TZSTR_429[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '7', '\0'};
static const UChar TZSTR_430[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '8', '\0'};
static const UChar TZSTR_431[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '-', '9', '\0'};
static const UChar TZSTR_432[] = {'E', 't', 'c', '/', 'G', 'M', 'T', '0', '\0'};
static const UChar TZSTR_433[] = {'E', 't', 'c', '/', 'G', 'r', 'e', 'e', 'n', 'w', 'i', 'c', 'h', '\0'};
static const UChar TZSTR_434[] = {'E', 't', 'c', '/', 'U', 'C', 'T', '\0'};
static const UChar TZSTR_435[] = {'E', 't', 'c', '/', 'U', 'T', 'C', '\0'};
static const UChar TZSTR_436[] = {'E', 't', 'c', '/', 'U', 'n', 'i', 'v', 'e', 'r', 's', 'a', 'l', '\0'};
static const UChar TZSTR_437[] = {'E', 't', 'c', '/', 'Z', 'u', 'l', 'u', '\0'};
static const UChar TZSTR_438[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'A', 'm', 's', 't', 'e', 'r', 'd', 'a', 'm', '\0'};
static const UChar TZSTR_439[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'A', 'n', 'd', 'o', 'r', 'r', 'a', '\0'};
static const UChar TZSTR_440[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'A', 's', 't', 'r', 'a', 'k', 'h', 'a', 'n', '\0'};
static const UChar TZSTR_441[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'A', 't', 'h', 'e', 'n', 's', '\0'};
static const UChar TZSTR_442[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'e', 'l', 'f', 'a', 's', 't', '\0'};
static const UChar TZSTR_443[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'e', 'l', 'g', 'r', 'a', 'd', 'e', '\0'};
static const UChar TZSTR_444[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'e', 'r', 'l', 'i', 'n', '\0'};
static const UChar TZSTR_445[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'r', 'a', 't', 'i', 's', 'l', 'a', 'v', 'a', '\0'};
static const UChar TZSTR_446[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'r', 'u', 's', 's', 'e', 'l', 's', '\0'};
static const UChar TZSTR_447[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'u', 'c', 'h', 'a', 'r', 'e', 's', 't', '\0'};
static const UChar TZSTR_448[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'u', 'd', 'a', 'p', 'e', 's', 't', '\0'};
static const UChar TZSTR_449[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'B', 'u', 's', 'i', 'n', 'g', 'e', 'n', '\0'};
static const UChar TZSTR_450[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'C', 'h', 'i', 's', 'i', 'n', 'a', 'u', '\0'};
static const UChar TZSTR_451[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'C', 'o', 'p', 'e', 'n', 'h', 'a', 'g', 'e', 'n', '\0'};
static const UChar TZSTR_452[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'D', 'u', 'b', 'l', 'i', 'n', '\0'};
static const UChar TZSTR_453[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'G', 'i', 'b', 'r', 'a', 'l', 't', 'a', 'r', '\0'};
static const UChar TZSTR_454[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'G', 'u', 'e', 'r', 'n', 's', 'e', 'y', '\0'};
static const UChar TZSTR_455[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'H', 'e', 'l', 's', 'i', 'n', 'k', 'i', '\0'};
static const UChar TZSTR_456[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'I', 's', 'l', 'e', '_', 'o', 'f', '_', 'M', 'a', 'n', '\0'};
static const UChar TZSTR_457[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'I', 's', 't', 'a', 'n', 'b', 'u', 'l', '\0'};
static const UChar TZSTR_458[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'J', 'e', 'r', 's', 'e', 'y', '\0'};
static const UChar TZSTR_459[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'K', 'a', 'l', 'i', 'n', 'i', 'n', 'g', 'r', 'a', 'd', '\0'};
static const UChar TZSTR_460[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'K', 'i', 'e', 'v', '\0'};
static const UChar TZSTR_461[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'K', 'i', 'r', 'o', 'v', '\0'};
static const UChar TZSTR_462[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'L', 'i', 's', 'b', 'o', 'n', '\0'};
static const UChar TZSTR_463[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'L', 'j', 'u', 'b', 'l', 'j', 'a', 'n', 'a', '\0'};
static const UChar TZSTR_464[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'L', 'o', 'n', 'd', 'o', 'n', '\0'};
static const UChar TZSTR_465[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'L', 'u', 'x', 'e', 'm', 'b', 'o', 'u', 'r', 'g', '\0'};
static const UChar TZSTR_466[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'M', 'a', 'd', 'r', 'i', 'd', '\0'};
static const UChar TZSTR_467[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'M', 'a', 'l', 't', 'a', '\0'};
static const UChar TZSTR_468[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'M', 'a', 'r', 'i', 'e', 'h', 'a', 'm', 'n', '\0'};
static const UChar TZSTR_469[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'M', 'i', 'n', 's', 'k', '\0'};
static const UChar TZSTR_470[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'M', 'o', 'n', 'a', 'c', 'o', '\0'};
static const UChar TZSTR_471[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'M', 'o', 's', 'c', 'o', 'w', '\0'};
static const UChar TZSTR_472[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'N', 'i', 'c', 'o', 's', 'i', 'a', '\0'};
static const UChar TZSTR_473[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'O', 's', 'l', 'o', '\0'};
static const UChar TZSTR_474[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'P', 'a', 'r', 'i', 's', '\0'};
static const UChar TZSTR_475[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'P', 'o', 'd', 'g', 'o', 'r', 'i', 'c', 'a', '\0'};
static const UChar TZSTR_476[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'P', 'r', 'a', 'g', 'u', 'e', '\0'};
static const UChar TZSTR_477[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'R', 'i', 'g', 'a', '\0'};
static const UChar TZSTR_478[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'R', 'o', 'm', 'e', '\0'};
static const UChar TZSTR_479[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'a', 'm', 'a', 'r', 'a', '\0'};
static const UChar TZSTR_480[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'a', 'n', '_', 'M', 'a', 'r', 'i', 'n', 'o', '\0'};
static const UChar TZSTR_481[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'a', 'r', 'a', 'j', 'e', 'v', 'o', '\0'};
static const UChar TZSTR_482[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'a', 'r', 'a', 't', 'o', 'v', '\0'};
static const UChar TZSTR_483[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'i', 'm', 'f', 'e', 'r', 'o', 'p', 'o', 'l', '\0'};
static const UChar TZSTR_484[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'k', 'o', 'p', 'j', 'e', '\0'};
static const UChar TZSTR_485[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 'o', 'f', 'i', 'a', '\0'};
static const UChar TZSTR_486[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'S', 't', 'o', 'c', 'k', 'h', 'o', 'l', 'm', '\0'};
static const UChar TZSTR_487[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'T', 'a', 'l', 'l', 'i', 'n', 'n', '\0'};
static const UChar TZSTR_488[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'T', 'i', 'r', 'a', 'n', 'e', '\0'};
static const UChar TZSTR_489[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'T', 'i', 'r', 'a', 's', 'p', 'o', 'l', '\0'};
static const UChar TZSTR_490[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'U', 'l', 'y', 'a', 'n', 'o', 'v', 's', 'k', '\0'};
static const UChar TZSTR_491[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'U', 'z', 'h', 'g', 'o', 'r', 'o', 'd', '\0'};
static const UChar TZSTR_492[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'V', 'a', 'd', 'u', 'z', '\0'};
static const UChar TZSTR_493[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'V', 'a', 't', 'i', 'c', 'a', 'n', '\0'};
static const UChar TZSTR_494[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'V', 'i', 'e', 'n', 'n', 'a', '\0'};
static const UChar TZSTR_495[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'V', 'i', 'l', 'n', 'i', 'u', 's', '\0'};
static const UChar TZSTR_496[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'V', 'o', 'l', 'g', 'o', 'g', 'r', 'a', 'd', '\0'};
static const UChar TZSTR_497[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'W', 'a', 'r', 's', 'a', 'w', '\0'};
static const UChar TZSTR_498[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'Z', 'a', 'g', 'r', 'e', 'b', '\0'};
static const UChar TZSTR_499[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'Z', 'a', 'p', 'o', 'r', 'o', 'z', 'h', 'y', 'e', '\0'};
static const UChar TZSTR_500[] = {'E', 'u', 'r', 'o', 'p', 'e', '/', 'Z', 'u', 'r', 'i', 'c', 'h', '\0'};
static const UChar TZSTR_501[] = {'F', 'a', 'c', 't', 'o', 'r', 'y', '\0'};
static const UChar TZSTR_502[] = {'G', 'B', '\0'};
static const UChar TZSTR_503[] = {'G', 'B', '-', 'E', 'i', 'r', 'e', '\0'};
static const UChar TZSTR_504[] = {'G', 'M', 'T', '+', '0', '\0'};
static const UChar TZSTR_505[] = {'G', 'M', 'T', '-', '0', '\0'};
static const UChar TZSTR_506[] = {'G', 'M', 'T', '0', '\0'};
static const UChar TZSTR_507[] = {'G', 'r', 'e', 'e', 'n', 'w', 'i', 'c', 'h', '\0'};
static const UChar TZSTR_508[] = {'H', 'S', 'T', '\0'};
static const UChar TZSTR_509[] = {'H', 'o', 'n', 'g', 'k', 'o', 'n', 'g', '\0'};
static const UChar TZSTR_510[] = {'I', 'E', 'T', '\0'};
static const UChar TZSTR_511[] = {'I', 'S', 'T', '\0'};
static const UChar TZSTR_512[] = {'I', 'c', 'e', 'l', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_513[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'A', 'n', 't', 'a', 'n', 'a', 'n', 'a', 'r', 'i', 'v', 'o', '\0'};
static const UChar TZSTR_514[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'C', 'h', 'a', 'g', 'o', 's', '\0'};
static const UChar TZSTR_515[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'C', 'h', 'r', 'i', 's', 't', 'm', 'a', 's', '\0'};
static const UChar TZSTR_516[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'C', 'o', 'c', 'o', 's', '\0'};
static const UChar TZSTR_517[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'C', 'o', 'm', 'o', 'r', 'o', '\0'};
static const UChar TZSTR_518[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'K', 'e', 'r', 'g', 'u', 'e', 'l', 'e', 'n', '\0'};
static const UChar TZSTR_519[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'M', 'a', 'h', 'e', '\0'};
static const UChar TZSTR_520[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'M', 'a', 'l', 'd', 'i', 'v', 'e', 's', '\0'};
static const UChar TZSTR_521[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'M', 'a', 'u', 'r', 'i', 't', 'i', 'u', 's', '\0'};
static const UChar TZSTR_522[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'M', 'a', 'y', 'o', 't', 't', 'e', '\0'};
static const UChar TZSTR_523[] = {'I', 'n', 'd', 'i', 'a', 'n', '/', 'R', 'e', 'u', 'n', 'i', 'o', 'n', '\0'};
static const UChar TZSTR_524[] = {'I', 'r', 'a', 'n', '\0'};
static const UChar TZSTR_525[] = {'I', 's', 'r', 'a', 'e', 'l', '\0'};
static const UChar TZSTR_526[] = {'J', 'S', 'T', '\0'};
static const UChar TZSTR_527[] = {'J', 'a', 'm', 'a', 'i', 'c', 'a', '\0'};
static const UChar TZSTR_528[] = {'J', 'a', 'p', 'a', 'n', '\0'};
static const UChar TZSTR_529[] = {'K', 'w', 'a', 'j', 'a', 'l', 'e', 'i', 'n', '\0'};
static const UChar TZSTR_530[] = {'L', 'i', 'b', 'y', 'a', '\0'};
static const UChar TZSTR_531[] = {'M', 'E', 'T', '\0'};
static const UChar TZSTR_532[] = {'M', 'I', 'T', '\0'};
static const UChar TZSTR_533[] = {'M', 'S', 'T', '\0'};
static const UChar TZSTR_534[] = {'M', 'S', 'T', '7', 'M', 'D', 'T', '\0'};
static const UChar TZSTR_535[] = {'M', 'e', 'x', 'i', 'c', 'o', '/', 'B', 'a', 'j', 'a', 'N', 'o', 'r', 't', 'e', '\0'};
static const UChar TZSTR_536[] = {'M', 'e', 'x', 'i', 'c', 'o', '/', 'B', 'a', 'j', 'a', 'S', 'u', 'r', '\0'};
static const UChar TZSTR_537[] = {'M', 'e', 'x', 'i', 'c', 'o', '/', 'G', 'e', 'n', 'e', 'r', 'a', 'l', '\0'};
static const UChar TZSTR_538[] = {'N', 'E', 'T', '\0'};
static const UChar TZSTR_539[] = {'N', 'S', 'T', '\0'};
static const UChar TZSTR_540[] = {'N', 'Z', '\0'};
static const UChar TZSTR_541[] = {'N', 'Z', '-', 'C', 'H', 'A', 'T', '\0'};
static const UChar TZSTR_542[] = {'N', 'a', 'v', 'a', 'j', 'o', '\0'};
static const UChar TZSTR_543[] = {'P', 'L', 'T', '\0'};
static const UChar TZSTR_544[] = {'P', 'N', 'T', '\0'};
static const UChar TZSTR_545[] = {'P', 'R', 'C', '\0'};
static const UChar TZSTR_546[] = {'P', 'R', 'T', '\0'};
static const UChar TZSTR_547[] = {'P', 'S', 'T', '\0'};
static const UChar TZSTR_548[] = {'P', 'S', 'T', '8', 'P', 'D', 'T', '\0'};
static const UChar TZSTR_549[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'A', 'p', 'i', 'a', '\0'};
static const UChar TZSTR_550[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'A', 'u', 'c', 'k', 'l', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_551[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'B', 'o', 'u', 'g', 'a', 'i', 'n', 'v', 'i', 'l', 'l', 'e', '\0'};
static const UChar TZSTR_552[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'C', 'h', 'a', 't', 'h', 'a', 'm', '\0'};
static const UChar TZSTR_553[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'C', 'h', 'u', 'u', 'k', '\0'};
static const UChar TZSTR_554[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'E', 'a', 's', 't', 'e', 'r', '\0'};
static const UChar TZSTR_555[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'E', 'f', 'a', 't', 'e', '\0'};
static const UChar TZSTR_556[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'E', 'n', 'd', 'e', 'r', 'b', 'u', 'r', 'y', '\0'};
static const UChar TZSTR_557[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'F', 'a', 'k', 'a', 'o', 'f', 'o', '\0'};
static const UChar TZSTR_558[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'F', 'i', 'j', 'i', '\0'};
static const UChar TZSTR_559[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'F', 'u', 'n', 'a', 'f', 'u', 't', 'i', '\0'};
static const UChar TZSTR_560[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'G', 'a', 'l', 'a', 'p', 'a', 'g', 'o', 's', '\0'};
static const UChar TZSTR_561[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'G', 'a', 'm', 'b', 'i', 'e', 'r', '\0'};
static const UChar TZSTR_562[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'G', 'u', 'a', 'd', 'a', 'l', 'c', 'a', 'n', 'a', 'l', '\0'};
static const UChar TZSTR_563[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'G', 'u', 'a', 'm', '\0'};
static const UChar TZSTR_564[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'H', 'o', 'n', 'o', 'l', 'u', 'l', 'u', '\0'};
static const UChar TZSTR_565[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'J', 'o', 'h', 'n', 's', 't', 'o', 'n', '\0'};
static const UChar TZSTR_566[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'K', 'i', 'r', 'i', 't', 'i', 'm', 'a', 't', 'i', '\0'};
static const UChar TZSTR_567[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'K', 'o', 's', 'r', 'a', 'e', '\0'};
static const UChar TZSTR_568[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'K', 'w', 'a', 'j', 'a', 'l', 'e', 'i', 'n', '\0'};
static const UChar TZSTR_569[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'M', 'a', 'j', 'u', 'r', 'o', '\0'};
static const UChar TZSTR_570[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'M', 'a', 'r', 'q', 'u', 'e', 's', 'a', 's', '\0'};
static const UChar TZSTR_571[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'M', 'i', 'd', 'w', 'a', 'y', '\0'};
static const UChar TZSTR_572[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'N', 'a', 'u', 'r', 'u', '\0'};
static const UChar TZSTR_573[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'N', 'i', 'u', 'e', '\0'};
static const UChar TZSTR_574[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'N', 'o', 'r', 'f', 'o', 'l', 'k', '\0'};
static const UChar TZSTR_575[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'N', 'o', 'u', 'm', 'e', 'a', '\0'};
static const UChar TZSTR_576[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'P', 'a', 'g', 'o', '_', 'P', 'a', 'g', 'o', '\0'};
static const UChar TZSTR_577[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'P', 'a', 'l', 'a', 'u', '\0'};
static const UChar TZSTR_578[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'P', 'i', 't', 'c', 'a', 'i', 'r', 'n', '\0'};
static const UChar TZSTR_579[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'P', 'o', 'h', 'n', 'p', 'e', 'i', '\0'};
static const UChar TZSTR_580[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'P', 'o', 'n', 'a', 'p', 'e', '\0'};
static const UChar TZSTR_581[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'P', 'o', 'r', 't', '_', 'M', 'o', 'r', 'e', 's', 'b', 'y', '\0'};
static const UChar TZSTR_582[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'R', 'a', 'r', 'o', 't', 'o', 'n', 'g', 'a', '\0'};
static const UChar TZSTR_583[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'S', 'a', 'i', 'p', 'a', 'n', '\0'};
static const UChar TZSTR_584[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'S', 'a', 'm', 'o', 'a', '\0'};
static const UChar TZSTR_585[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'T', 'a', 'h', 'i', 't', 'i', '\0'};
static const UChar TZSTR_586[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'T', 'a', 'r', 'a', 'w', 'a', '\0'};
static const UChar TZSTR_587[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'T', 'o', 'n', 'g', 'a', 't', 'a', 'p', 'u', '\0'};
static const UChar TZSTR_588[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'T', 'r', 'u', 'k', '\0'};
static const UChar TZSTR_589[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'W', 'a', 'k', 'e', '\0'};
static const UChar TZSTR_590[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'W', 'a', 'l', 'l', 'i', 's', '\0'};
static const UChar TZSTR_591[] = {'P', 'a', 'c', 'i', 'f', 'i', 'c', '/', 'Y', 'a', 'p', '\0'};
static const UChar TZSTR_592[] = {'P', 'o', 'l', 'a', 'n', 'd', '\0'};
static const UChar TZSTR_593[] = {'P', 'o', 'r', 't', 'u', 'g', 'a', 'l', '\0'};
static const UChar TZSTR_594[] = {'R', 'O', 'C', '\0'};
static const UChar TZSTR_595[] = {'R', 'O', 'K', '\0'};
static const UChar TZSTR_596[] = {'S', 'S', 'T', '\0'};
static const UChar TZSTR_597[] = {'S', 'i', 'n', 'g', 'a', 'p', 'o', 'r', 'e', '\0'};
static const UChar TZSTR_598[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'A', 'S', 'T', '4', '\0'};
static const UChar TZSTR_599[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'A', 'S', 'T', '4', 'A', 'D', 'T', '\0'};
static const UChar TZSTR_600[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'C', 'S', 'T', '6', '\0'};
static const UChar TZSTR_601[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'C', 'S', 'T', '6', 'C', 'D', 'T', '\0'};
static const UChar TZSTR_602[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'E', 'S', 'T', '5', '\0'};
static const UChar TZSTR_603[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'E', 'S', 'T', '5', 'E', 'D', 'T', '\0'};
static const UChar TZSTR_604[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'H', 'S', 'T', '1', '0', '\0'};
static const UChar TZSTR_605[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'M', 'S', 'T', '7', '\0'};
static const UChar TZSTR_606[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'M', 'S', 'T', '7', 'M', 'D', 'T', '\0'};
static const UChar TZSTR_607[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'P', 'S', 'T', '8', '\0'};
static const UChar TZSTR_608[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'P', 'S', 'T', '8', 'P', 'D', 'T', '\0'};
static const UChar TZSTR_609[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'Y', 'S', 'T', '9', '\0'};
static const UChar TZSTR_610[] = {'S', 'y', 's', 't', 'e', 'm', 'V', '/', 'Y', 'S', 'T', '9', 'Y', 'D', 'T', '\0'};
static const UChar TZSTR_611[] = {'T', 'u', 'r', 'k', 'e', 'y', '\0'};
static const UChar TZSTR_612[] = {'U', 'C', 'T', '\0'};
static const UChar TZSTR_613[] = {'U', 'S', '/', 'A', 'l', 'a', 's', 'k', 'a', '\0'};
static const UChar TZSTR_614[] = {'U', 'S', '/', 'A', 'l', 'e', 'u', 't', 'i', 'a', 'n', '\0'};
static const UChar TZSTR_615[] = {'U', 'S', '/', 'A', 'r', 'i', 'z', 'o', 'n', 'a', '\0'};
static const UChar TZSTR_616[] = {'U', 'S', '/', 'C', 'e', 'n', 't', 'r', 'a', 'l', '\0'};
static const UChar TZSTR_617[] = {'U', 'S', '/', 'E', 'a', 's', 't', '-', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '\0'};
static const UChar TZSTR_618[] = {'U', 'S', '/', 'E', 'a', 's', 't', 'e', 'r', 'n', '\0'};
static const UChar TZSTR_619[] = {'U', 'S', '/', 'H', 'a', 'w', 'a', 'i', 'i', '\0'};
static const UChar TZSTR_620[] = {'U', 'S', '/', 'I', 'n', 'd', 'i', 'a', 'n', 'a', '-', 'S', 't', 'a', 'r', 'k', 'e', '\0'};
static const UChar TZSTR_621[] = {'U', 'S', '/', 'M', 'i', 'c', 'h', 'i', 'g', 'a', 'n', '\0'};
static const UChar TZSTR_622[] = {'U', 'S', '/', 'M', 'o', 'u', 'n', 't', 'a', 'i', 'n', '\0'};
static const UChar TZSTR_623[] = {'U', 'S', '/', 'P', 'a', 'c', 'i', 'f', 'i', 'c', '\0'};
static const UChar TZSTR_624[] = {'U', 'S', '/', 'P', 'a', 'c', 'i', 'f', 'i', 'c', '-', 'N', 'e', 'w', '\0'};
static const UChar TZSTR_625[] = {'U', 'S', '/', 'S', 'a', 'm', 'o', 'a', '\0'};
static const UChar TZSTR_626[] = {'U', 'T', 'C', '\0'};
static const UChar TZSTR_627[] = {'U', 'n', 'i', 'v', 'e', 'r', 's', 'a', 'l', '\0'};
static const UChar TZSTR_628[] = {'V', 'S', 'T', '\0'};
static const UChar TZSTR_629[] = {'W', '-', 'S', 'U', '\0'};
static const UChar TZSTR_630[] = {'W', 'E', 'T', '\0'};
static const UChar TZSTR_631[] = {'Z', 'u', 'l', 'u', '\0'};

// Do not change order of items in this array! The index corresponds to a TimeZone ID, which must be fixed!
static const TimeZoneDesc TIME_ZONE_LIST[] = {
	{"GMT", TZSTR_0},
	{"ACT", TZSTR_1},
	{"AET", TZSTR_2},
	{"AGT", TZSTR_3},
	{"ART", TZSTR_4},
	{"AST", TZSTR_5},
	{"Africa/Abidjan", TZSTR_6},
	{"Africa/Accra", TZSTR_7},
	{"Africa/Addis_Ababa", TZSTR_8},
	{"Africa/Algiers", TZSTR_9},
	{"Africa/Asmara", TZSTR_10},
	{"Africa/Asmera", TZSTR_11},
	{"Africa/Bamako", TZSTR_12},
	{"Africa/Bangui", TZSTR_13},
	{"Africa/Banjul", TZSTR_14},
	{"Africa/Bissau", TZSTR_15},
	{"Africa/Blantyre", TZSTR_16},
	{"Africa/Brazzaville", TZSTR_17},
	{"Africa/Bujumbura", TZSTR_18},
	{"Africa/Cairo", TZSTR_19},
	{"Africa/Casablanca", TZSTR_20},
	{"Africa/Ceuta", TZSTR_21},
	{"Africa/Conakry", TZSTR_22},
	{"Africa/Dakar", TZSTR_23},
	{"Africa/Dar_es_Salaam", TZSTR_24},
	{"Africa/Djibouti", TZSTR_25},
	{"Africa/Douala", TZSTR_26},
	{"Africa/El_Aaiun", TZSTR_27},
	{"Africa/Freetown", TZSTR_28},
	{"Africa/Gaborone", TZSTR_29},
	{"Africa/Harare", TZSTR_30},
	{"Africa/Johannesburg", TZSTR_31},
	{"Africa/Juba", TZSTR_32},
	{"Africa/Kampala", TZSTR_33},
	{"Africa/Khartoum", TZSTR_34},
	{"Africa/Kigali", TZSTR_35},
	{"Africa/Kinshasa", TZSTR_36},
	{"Africa/Lagos", TZSTR_37},
	{"Africa/Libreville", TZSTR_38},
	{"Africa/Lome", TZSTR_39},
	{"Africa/Luanda", TZSTR_40},
	{"Africa/Lubumbashi", TZSTR_41},
	{"Africa/Lusaka", TZSTR_42},
	{"Africa/Malabo", TZSTR_43},
	{"Africa/Maputo", TZSTR_44},
	{"Africa/Maseru", TZSTR_45},
	{"Africa/Mbabane", TZSTR_46},
	{"Africa/Mogadishu", TZSTR_47},
	{"Africa/Monrovia", TZSTR_48},
	{"Africa/Nairobi", TZSTR_49},
	{"Africa/Ndjamena", TZSTR_50},
	{"Africa/Niamey", TZSTR_51},
	{"Africa/Nouakchott", TZSTR_52},
	{"Africa/Ouagadougou", TZSTR_53},
	{"Africa/Porto-Novo", TZSTR_54},
	{"Africa/Sao_Tome", TZSTR_55},
	{"Africa/Timbuktu", TZSTR_56},
	{"Africa/Tripoli", TZSTR_57},
	{"Africa/Tunis", TZSTR_58},
	{"Africa/Windhoek", TZSTR_59},
	{"America/Adak", TZSTR_60},
	{"America/Anchorage", TZSTR_61},
	{"America/Anguilla", TZSTR_62},
	{"America/Antigua", TZSTR_63},
	{"America/Araguaina", TZSTR_64},
	{"America/Argentina/Buenos_Aires", TZSTR_65},
	{"America/Argentina/Catamarca", TZSTR_66},
	{"America/Argentina/ComodRivadavia", TZSTR_67},
	{"America/Argentina/Cordoba", TZSTR_68},
	{"America/Argentina/Jujuy", TZSTR_69},
	{"America/Argentina/La_Rioja", TZSTR_70},
	{"America/Argentina/Mendoza", TZSTR_71},
	{"America/Argentina/Rio_Gallegos", TZSTR_72},
	{"America/Argentina/Salta", TZSTR_73},
	{"America/Argentina/San_Juan", TZSTR_74},
	{"America/Argentina/San_Luis", TZSTR_75},
	{"America/Argentina/Tucuman", TZSTR_76},
	{"America/Argentina/Ushuaia", TZSTR_77},
	{"America/Aruba", TZSTR_78},
	{"America/Asuncion", TZSTR_79},
	{"America/Atikokan", TZSTR_80},
	{"America/Atka", TZSTR_81},
	{"America/Bahia", TZSTR_82},
	{"America/Bahia_Banderas", TZSTR_83},
	{"America/Barbados", TZSTR_84},
	{"America/Belem", TZSTR_85},
	{"America/Belize", TZSTR_86},
	{"America/Blanc-Sablon", TZSTR_87},
	{"America/Boa_Vista", TZSTR_88},
	{"America/Bogota", TZSTR_89},
	{"America/Boise", TZSTR_90},
	{"America/Buenos_Aires", TZSTR_91},
	{"America/Cambridge_Bay", TZSTR_92},
	{"America/Campo_Grande", TZSTR_93},
	{"America/Cancun", TZSTR_94},
	{"America/Caracas", TZSTR_95},
	{"America/Catamarca", TZSTR_96},
	{"America/Cayenne", TZSTR_97},
	{"America/Cayman", TZSTR_98},
	{"America/Chicago", TZSTR_99},
	{"America/Chihuahua", TZSTR_100},
	{"America/Coral_Harbour", TZSTR_101},
	{"America/Cordoba", TZSTR_102},
	{"America/Costa_Rica", TZSTR_103},
	{"America/Creston", TZSTR_104},
	{"America/Cuiaba", TZSTR_105},
	{"America/Curacao", TZSTR_106},
	{"America/Danmarkshavn", TZSTR_107},
	{"America/Dawson", TZSTR_108},
	{"America/Dawson_Creek", TZSTR_109},
	{"America/Denver", TZSTR_110},
	{"America/Detroit", TZSTR_111},
	{"America/Dominica", TZSTR_112},
	{"America/Edmonton", TZSTR_113},
	{"America/Eirunepe", TZSTR_114},
	{"America/El_Salvador", TZSTR_115},
	{"America/Ensenada", TZSTR_116},
	{"America/Fort_Nelson", TZSTR_117},
	{"America/Fort_Wayne", TZSTR_118},
	{"America/Fortaleza", TZSTR_119},
	{"America/Glace_Bay", TZSTR_120},
	{"America/Godthab", TZSTR_121},
	{"America/Goose_Bay", TZSTR_122},
	{"America/Grand_Turk", TZSTR_123},
	{"America/Grenada", TZSTR_124},
	{"America/Guadeloupe", TZSTR_125},
	{"America/Guatemala", TZSTR_126},
	{"America/Guayaquil", TZSTR_127},
	{"America/Guyana", TZSTR_128},
	{"America/Halifax", TZSTR_129},
	{"America/Havana", TZSTR_130},
	{"America/Hermosillo", TZSTR_131},
	{"America/Indiana/Indianapolis", TZSTR_132},
	{"America/Indiana/Knox", TZSTR_133},
	{"America/Indiana/Marengo", TZSTR_134},
	{"America/Indiana/Petersburg", TZSTR_135},
	{"America/Indiana/Tell_City", TZSTR_136},
	{"America/Indiana/Vevay", TZSTR_137},
	{"America/Indiana/Vincennes", TZSTR_138},
	{"America/Indiana/Winamac", TZSTR_139},
	{"America/Indianapolis", TZSTR_140},
	{"America/Inuvik", TZSTR_141},
	{"America/Iqaluit", TZSTR_142},
	{"America/Jamaica", TZSTR_143},
	{"America/Jujuy", TZSTR_144},
	{"America/Juneau", TZSTR_145},
	{"America/Kentucky/Louisville", TZSTR_146},
	{"America/Kentucky/Monticello", TZSTR_147},
	{"America/Knox_IN", TZSTR_148},
	{"America/Kralendijk", TZSTR_149},
	{"America/La_Paz", TZSTR_150},
	{"America/Lima", TZSTR_151},
	{"America/Los_Angeles", TZSTR_152},
	{"America/Louisville", TZSTR_153},
	{"America/Lower_Princes", TZSTR_154},
	{"America/Maceio", TZSTR_155},
	{"America/Managua", TZSTR_156},
	{"America/Manaus", TZSTR_157},
	{"America/Marigot", TZSTR_158},
	{"America/Martinique", TZSTR_159},
	{"America/Matamoros", TZSTR_160},
	{"America/Mazatlan", TZSTR_161},
	{"America/Mendoza", TZSTR_162},
	{"America/Menominee", TZSTR_163},
	{"America/Merida", TZSTR_164},
	{"America/Metlakatla", TZSTR_165},
	{"America/Mexico_City", TZSTR_166},
	{"America/Miquelon", TZSTR_167},
	{"America/Moncton", TZSTR_168},
	{"America/Monterrey", TZSTR_169},
	{"America/Montevideo", TZSTR_170},
	{"America/Montreal", TZSTR_171},
	{"America/Montserrat", TZSTR_172},
	{"America/Nassau", TZSTR_173},
	{"America/New_York", TZSTR_174},
	{"America/Nipigon", TZSTR_175},
	{"America/Nome", TZSTR_176},
	{"America/Noronha", TZSTR_177},
	{"America/North_Dakota/Beulah", TZSTR_178},
	{"America/North_Dakota/Center", TZSTR_179},
	{"America/North_Dakota/New_Salem", TZSTR_180},
	{"America/Ojinaga", TZSTR_181},
	{"America/Panama", TZSTR_182},
	{"America/Pangnirtung", TZSTR_183},
	{"America/Paramaribo", TZSTR_184},
	{"America/Phoenix", TZSTR_185},
	{"America/Port-au-Prince", TZSTR_186},
	{"America/Port_of_Spain", TZSTR_187},
	{"America/Porto_Acre", TZSTR_188},
	{"America/Porto_Velho", TZSTR_189},
	{"America/Puerto_Rico", TZSTR_190},
	{"America/Punta_Arenas", TZSTR_191},
	{"America/Rainy_River", TZSTR_192},
	{"America/Rankin_Inlet", TZSTR_193},
	{"America/Recife", TZSTR_194},
	{"America/Regina", TZSTR_195},
	{"America/Resolute", TZSTR_196},
	{"America/Rio_Branco", TZSTR_197},
	{"America/Rosario", TZSTR_198},
	{"America/Santa_Isabel", TZSTR_199},
	{"America/Santarem", TZSTR_200},
	{"America/Santiago", TZSTR_201},
	{"America/Santo_Domingo", TZSTR_202},
	{"America/Sao_Paulo", TZSTR_203},
	{"America/Scoresbysund", TZSTR_204},
	{"America/Shiprock", TZSTR_205},
	{"America/Sitka", TZSTR_206},
	{"America/St_Barthelemy", TZSTR_207},
	{"America/St_Johns", TZSTR_208},
	{"America/St_Kitts", TZSTR_209},
	{"America/St_Lucia", TZSTR_210},
	{"America/St_Thomas", TZSTR_211},
	{"America/St_Vincent", TZSTR_212},
	{"America/Swift_Current", TZSTR_213},
	{"America/Tegucigalpa", TZSTR_214},
	{"America/Thule", TZSTR_215},
	{"America/Thunder_Bay", TZSTR_216},
	{"America/Tijuana", TZSTR_217},
	{"America/Toronto", TZSTR_218},
	{"America/Tortola", TZSTR_219},
	{"America/Vancouver", TZSTR_220},
	{"America/Virgin", TZSTR_221},
	{"America/Whitehorse", TZSTR_222},
	{"America/Winnipeg", TZSTR_223},
	{"America/Yakutat", TZSTR_224},
	{"America/Yellowknife", TZSTR_225},
	{"Antarctica/Casey", TZSTR_226},
	{"Antarctica/Davis", TZSTR_227},
	{"Antarctica/DumontDUrville", TZSTR_228},
	{"Antarctica/Macquarie", TZSTR_229},
	{"Antarctica/Mawson", TZSTR_230},
	{"Antarctica/McMurdo", TZSTR_231},
	{"Antarctica/Palmer", TZSTR_232},
	{"Antarctica/Rothera", TZSTR_233},
	{"Antarctica/South_Pole", TZSTR_234},
	{"Antarctica/Syowa", TZSTR_235},
	{"Antarctica/Troll", TZSTR_236},
	{"Antarctica/Vostok", TZSTR_237},
	{"Arctic/Longyearbyen", TZSTR_238},
	{"Asia/Aden", TZSTR_239},
	{"Asia/Almaty", TZSTR_240},
	{"Asia/Amman", TZSTR_241},
	{"Asia/Anadyr", TZSTR_242},
	{"Asia/Aqtau", TZSTR_243},
	{"Asia/Aqtobe", TZSTR_244},
	{"Asia/Ashgabat", TZSTR_245},
	{"Asia/Ashkhabad", TZSTR_246},
	{"Asia/Atyrau", TZSTR_247},
	{"Asia/Baghdad", TZSTR_248},
	{"Asia/Bahrain", TZSTR_249},
	{"Asia/Baku", TZSTR_250},
	{"Asia/Bangkok", TZSTR_251},
	{"Asia/Barnaul", TZSTR_252},
	{"Asia/Beirut", TZSTR_253},
	{"Asia/Bishkek", TZSTR_254},
	{"Asia/Brunei", TZSTR_255},
	{"Asia/Calcutta", TZSTR_256},
	{"Asia/Chita", TZSTR_257},
	{"Asia/Choibalsan", TZSTR_258},
	{"Asia/Chongqing", TZSTR_259},
	{"Asia/Chungking", TZSTR_260},
	{"Asia/Colombo", TZSTR_261},
	{"Asia/Dacca", TZSTR_262},
	{"Asia/Damascus", TZSTR_263},
	{"Asia/Dhaka", TZSTR_264},
	{"Asia/Dili", TZSTR_265},
	{"Asia/Dubai", TZSTR_266},
	{"Asia/Dushanbe", TZSTR_267},
	{"Asia/Famagusta", TZSTR_268},
	{"Asia/Gaza", TZSTR_269},
	{"Asia/Harbin", TZSTR_270},
	{"Asia/Hebron", TZSTR_271},
	{"Asia/Ho_Chi_Minh", TZSTR_272},
	{"Asia/Hong_Kong", TZSTR_273},
	{"Asia/Hovd", TZSTR_274},
	{"Asia/Irkutsk", TZSTR_275},
	{"Asia/Istanbul", TZSTR_276},
	{"Asia/Jakarta", TZSTR_277},
	{"Asia/Jayapura", TZSTR_278},
	{"Asia/Jerusalem", TZSTR_279},
	{"Asia/Kabul", TZSTR_280},
	{"Asia/Kamchatka", TZSTR_281},
	{"Asia/Karachi", TZSTR_282},
	{"Asia/Kashgar", TZSTR_283},
	{"Asia/Kathmandu", TZSTR_284},
	{"Asia/Katmandu", TZSTR_285},
	{"Asia/Khandyga", TZSTR_286},
	{"Asia/Kolkata", TZSTR_287},
	{"Asia/Krasnoyarsk", TZSTR_288},
	{"Asia/Kuala_Lumpur", TZSTR_289},
	{"Asia/Kuching", TZSTR_290},
	{"Asia/Kuwait", TZSTR_291},
	{"Asia/Macao", TZSTR_292},
	{"Asia/Macau", TZSTR_293},
	{"Asia/Magadan", TZSTR_294},
	{"Asia/Makassar", TZSTR_295},
	{"Asia/Manila", TZSTR_296},
	{"Asia/Muscat", TZSTR_297},
	{"Asia/Nicosia", TZSTR_298},
	{"Asia/Novokuznetsk", TZSTR_299},
	{"Asia/Novosibirsk", TZSTR_300},
	{"Asia/Omsk", TZSTR_301},
	{"Asia/Oral", TZSTR_302},
	{"Asia/Phnom_Penh", TZSTR_303},
	{"Asia/Pontianak", TZSTR_304},
	{"Asia/Pyongyang", TZSTR_305},
	{"Asia/Qatar", TZSTR_306},
	{"Asia/Qyzylorda", TZSTR_307},
	{"Asia/Rangoon", TZSTR_308},
	{"Asia/Riyadh", TZSTR_309},
	{"Asia/Saigon", TZSTR_310},
	{"Asia/Sakhalin", TZSTR_311},
	{"Asia/Samarkand", TZSTR_312},
	{"Asia/Seoul", TZSTR_313},
	{"Asia/Shanghai", TZSTR_314},
	{"Asia/Singapore", TZSTR_315},
	{"Asia/Srednekolymsk", TZSTR_316},
	{"Asia/Taipei", TZSTR_317},
	{"Asia/Tashkent", TZSTR_318},
	{"Asia/Tbilisi", TZSTR_319},
	{"Asia/Tehran", TZSTR_320},
	{"Asia/Tel_Aviv", TZSTR_321},
	{"Asia/Thimbu", TZSTR_322},
	{"Asia/Thimphu", TZSTR_323},
	{"Asia/Tokyo", TZSTR_324},
	{"Asia/Tomsk", TZSTR_325},
	{"Asia/Ujung_Pandang", TZSTR_326},
	{"Asia/Ulaanbaatar", TZSTR_327},
	{"Asia/Ulan_Bator", TZSTR_328},
	{"Asia/Urumqi", TZSTR_329},
	{"Asia/Ust-Nera", TZSTR_330},
	{"Asia/Vientiane", TZSTR_331},
	{"Asia/Vladivostok", TZSTR_332},
	{"Asia/Yakutsk", TZSTR_333},
	{"Asia/Yangon", TZSTR_334},
	{"Asia/Yekaterinburg", TZSTR_335},
	{"Asia/Yerevan", TZSTR_336},
	{"Atlantic/Azores", TZSTR_337},
	{"Atlantic/Bermuda", TZSTR_338},
	{"Atlantic/Canary", TZSTR_339},
	{"Atlantic/Cape_Verde", TZSTR_340},
	{"Atlantic/Faeroe", TZSTR_341},
	{"Atlantic/Faroe", TZSTR_342},
	{"Atlantic/Jan_Mayen", TZSTR_343},
	{"Atlantic/Madeira", TZSTR_344},
	{"Atlantic/Reykjavik", TZSTR_345},
	{"Atlantic/South_Georgia", TZSTR_346},
	{"Atlantic/St_Helena", TZSTR_347},
	{"Atlantic/Stanley", TZSTR_348},
	{"Australia/ACT", TZSTR_349},
	{"Australia/Adelaide", TZSTR_350},
	{"Australia/Brisbane", TZSTR_351},
	{"Australia/Broken_Hill", TZSTR_352},
	{"Australia/Canberra", TZSTR_353},
	{"Australia/Currie", TZSTR_354},
	{"Australia/Darwin", TZSTR_355},
	{"Australia/Eucla", TZSTR_356},
	{"Australia/Hobart", TZSTR_357},
	{"Australia/LHI", TZSTR_358},
	{"Australia/Lindeman", TZSTR_359},
	{"Australia/Lord_Howe", TZSTR_360},
	{"Australia/Melbourne", TZSTR_361},
	{"Australia/NSW", TZSTR_362},
	{"Australia/North", TZSTR_363},
	{"Australia/Perth", TZSTR_364},
	{"Australia/Queensland", TZSTR_365},
	{"Australia/South", TZSTR_366},
	{"Australia/Sydney", TZSTR_367},
	{"Australia/Tasmania", TZSTR_368},
	{"Australia/Victoria", TZSTR_369},
	{"Australia/West", TZSTR_370},
	{"Australia/Yancowinna", TZSTR_371},
	{"BET", TZSTR_372},
	{"BST", TZSTR_373},
	{"Brazil/Acre", TZSTR_374},
	{"Brazil/DeNoronha", TZSTR_375},
	{"Brazil/East", TZSTR_376},
	{"Brazil/West", TZSTR_377},
	{"CAT", TZSTR_378},
	{"CET", TZSTR_379},
	{"CNT", TZSTR_380},
	{"CST", TZSTR_381},
	{"CST6CDT", TZSTR_382},
	{"CTT", TZSTR_383},
	{"Canada/Atlantic", TZSTR_384},
	{"Canada/Central", TZSTR_385},
	{"Canada/East-Saskatchewan", TZSTR_386},
	{"Canada/Eastern", TZSTR_387},
	{"Canada/Mountain", TZSTR_388},
	{"Canada/Newfoundland", TZSTR_389},
	{"Canada/Pacific", TZSTR_390},
	{"Canada/Saskatchewan", TZSTR_391},
	{"Canada/Yukon", TZSTR_392},
	{"Chile/Continental", TZSTR_393},
	{"Chile/EasterIsland", TZSTR_394},
	{"Cuba", TZSTR_395},
	{"EAT", TZSTR_396},
	{"ECT", TZSTR_397},
	{"EET", TZSTR_398},
	{"EST", TZSTR_399},
	{"EST5EDT", TZSTR_400},
	{"Egypt", TZSTR_401},
	{"Eire", TZSTR_402},
	{"Etc/GMT", TZSTR_403},
	{"Etc/GMT+0", TZSTR_404},
	{"Etc/GMT+1", TZSTR_405},
	{"Etc/GMT+10", TZSTR_406},
	{"Etc/GMT+11", TZSTR_407},
	{"Etc/GMT+12", TZSTR_408},
	{"Etc/GMT+2", TZSTR_409},
	{"Etc/GMT+3", TZSTR_410},
	{"Etc/GMT+4", TZSTR_411},
	{"Etc/GMT+5", TZSTR_412},
	{"Etc/GMT+6", TZSTR_413},
	{"Etc/GMT+7", TZSTR_414},
	{"Etc/GMT+8", TZSTR_415},
	{"Etc/GMT+9", TZSTR_416},
	{"Etc/GMT-0", TZSTR_417},
	{"Etc/GMT-1", TZSTR_418},
	{"Etc/GMT-10", TZSTR_419},
	{"Etc/GMT-11", TZSTR_420},
	{"Etc/GMT-12", TZSTR_421},
	{"Etc/GMT-13", TZSTR_422},
	{"Etc/GMT-14", TZSTR_423},
	{"Etc/GMT-2", TZSTR_424},
	{"Etc/GMT-3", TZSTR_425},
	{"Etc/GMT-4", TZSTR_426},
	{"Etc/GMT-5", TZSTR_427},
	{"Etc/GMT-6", TZSTR_428},
	{"Etc/GMT-7", TZSTR_429},
	{"Etc/GMT-8", TZSTR_430},
	{"Etc/GMT-9", TZSTR_431},
	{"Etc/GMT0", TZSTR_432},
	{"Etc/Greenwich", TZSTR_433},
	{"Etc/UCT", TZSTR_434},
	{"Etc/UTC", TZSTR_435},
	{"Etc/Universal", TZSTR_436},
	{"Etc/Zulu", TZSTR_437},
	{"Europe/Amsterdam", TZSTR_438},
	{"Europe/Andorra", TZSTR_439},
	{"Europe/Astrakhan", TZSTR_440},
	{"Europe/Athens", TZSTR_441},
	{"Europe/Belfast", TZSTR_442},
	{"Europe/Belgrade", TZSTR_443},
	{"Europe/Berlin", TZSTR_444},
	{"Europe/Bratislava", TZSTR_445},
	{"Europe/Brussels", TZSTR_446},
	{"Europe/Bucharest", TZSTR_447},
	{"Europe/Budapest", TZSTR_448},
	{"Europe/Busingen", TZSTR_449},
	{"Europe/Chisinau", TZSTR_450},
	{"Europe/Copenhagen", TZSTR_451},
	{"Europe/Dublin", TZSTR_452},
	{"Europe/Gibraltar", TZSTR_453},
	{"Europe/Guernsey", TZSTR_454},
	{"Europe/Helsinki", TZSTR_455},
	{"Europe/Isle_of_Man", TZSTR_456},
	{"Europe/Istanbul", TZSTR_457},
	{"Europe/Jersey", TZSTR_458},
	{"Europe/Kaliningrad", TZSTR_459},
	{"Europe/Kiev", TZSTR_460},
	{"Europe/Kirov", TZSTR_461},
	{"Europe/Lisbon", TZSTR_462},
	{"Europe/Ljubljana", TZSTR_463},
	{"Europe/London", TZSTR_464},
	{"Europe/Luxembourg", TZSTR_465},
	{"Europe/Madrid", TZSTR_466},
	{"Europe/Malta", TZSTR_467},
	{"Europe/Mariehamn", TZSTR_468},
	{"Europe/Minsk", TZSTR_469},
	{"Europe/Monaco", TZSTR_470},
	{"Europe/Moscow", TZSTR_471},
	{"Europe/Nicosia", TZSTR_472},
	{"Europe/Oslo", TZSTR_473},
	{"Europe/Paris", TZSTR_474},
	{"Europe/Podgorica", TZSTR_475},
	{"Europe/Prague", TZSTR_476},
	{"Europe/Riga", TZSTR_477},
	{"Europe/Rome", TZSTR_478},
	{"Europe/Samara", TZSTR_479},
	{"Europe/San_Marino", TZSTR_480},
	{"Europe/Sarajevo", TZSTR_481},
	{"Europe/Saratov", TZSTR_482},
	{"Europe/Simferopol", TZSTR_483},
	{"Europe/Skopje", TZSTR_484},
	{"Europe/Sofia", TZSTR_485},
	{"Europe/Stockholm", TZSTR_486},
	{"Europe/Tallinn", TZSTR_487},
	{"Europe/Tirane", TZSTR_488},
	{"Europe/Tiraspol", TZSTR_489},
	{"Europe/Ulyanovsk", TZSTR_490},
	{"Europe/Uzhgorod", TZSTR_491},
	{"Europe/Vaduz", TZSTR_492},
	{"Europe/Vatican", TZSTR_493},
	{"Europe/Vienna", TZSTR_494},
	{"Europe/Vilnius", TZSTR_495},
	{"Europe/Volgograd", TZSTR_496},
	{"Europe/Warsaw", TZSTR_497},
	{"Europe/Zagreb", TZSTR_498},
	{"Europe/Zaporozhye", TZSTR_499},
	{"Europe/Zurich", TZSTR_500},
	{"Factory", TZSTR_501},
	{"GB", TZSTR_502},
	{"GB-Eire", TZSTR_503},
	{"GMT+0", TZSTR_504},
	{"GMT-0", TZSTR_505},
	{"GMT0", TZSTR_506},
	{"Greenwich", TZSTR_507},
	{"HST", TZSTR_508},
	{"Hongkong", TZSTR_509},
	{"IET", TZSTR_510},
	{"IST", TZSTR_511},
	{"Iceland", TZSTR_512},
	{"Indian/Antananarivo", TZSTR_513},
	{"Indian/Chagos", TZSTR_514},
	{"Indian/Christmas", TZSTR_515},
	{"Indian/Cocos", TZSTR_516},
	{"Indian/Comoro", TZSTR_517},
	{"Indian/Kerguelen", TZSTR_518},
	{"Indian/Mahe", TZSTR_519},
	{"Indian/Maldives", TZSTR_520},
	{"Indian/Mauritius", TZSTR_521},
	{"Indian/Mayotte", TZSTR_522},
	{"Indian/Reunion", TZSTR_523},
	{"Iran", TZSTR_524},
	{"Israel", TZSTR_525},
	{"JST", TZSTR_526},
	{"Jamaica", TZSTR_527},
	{"Japan", TZSTR_528},
	{"Kwajalein", TZSTR_529},
	{"Libya", TZSTR_530},
	{"MET", TZSTR_531},
	{"MIT", TZSTR_532},
	{"MST", TZSTR_533},
	{"MST7MDT", TZSTR_534},
	{"Mexico/BajaNorte", TZSTR_535},
	{"Mexico/BajaSur", TZSTR_536},
	{"Mexico/General", TZSTR_537},
	{"NET", TZSTR_538},
	{"NST", TZSTR_539},
	{"NZ", TZSTR_540},
	{"NZ-CHAT", TZSTR_541},
	{"Navajo", TZSTR_542},
	{"PLT", TZSTR_543},
	{"PNT", TZSTR_544},
	{"PRC", TZSTR_545},
	{"PRT", TZSTR_546},
	{"PST", TZSTR_547},
	{"PST8PDT", TZSTR_548},
	{"Pacific/Apia", TZSTR_549},
	{"Pacific/Auckland", TZSTR_550},
	{"Pacific/Bougainville", TZSTR_551},
	{"Pacific/Chatham", TZSTR_552},
	{"Pacific/Chuuk", TZSTR_553},
	{"Pacific/Easter", TZSTR_554},
	{"Pacific/Efate", TZSTR_555},
	{"Pacific/Enderbury", TZSTR_556},
	{"Pacific/Fakaofo", TZSTR_557},
	{"Pacific/Fiji", TZSTR_558},
	{"Pacific/Funafuti", TZSTR_559},
	{"Pacific/Galapagos", TZSTR_560},
	{"Pacific/Gambier", TZSTR_561},
	{"Pacific/Guadalcanal", TZSTR_562},
	{"Pacific/Guam", TZSTR_563},
	{"Pacific/Honolulu", TZSTR_564},
	{"Pacific/Johnston", TZSTR_565},
	{"Pacific/Kiritimati", TZSTR_566},
	{"Pacific/Kosrae", TZSTR_567},
	{"Pacific/Kwajalein", TZSTR_568},
	{"Pacific/Majuro", TZSTR_569},
	{"Pacific/Marquesas", TZSTR_570},
	{"Pacific/Midway", TZSTR_571},
	{"Pacific/Nauru", TZSTR_572},
	{"Pacific/Niue", TZSTR_573},
	{"Pacific/Norfolk", TZSTR_574},
	{"Pacific/Noumea", TZSTR_575},
	{"Pacific/Pago_Pago", TZSTR_576},
	{"Pacific/Palau", TZSTR_577},
	{"Pacific/Pitcairn", TZSTR_578},
	{"Pacific/Pohnpei", TZSTR_579},
	{"Pacific/Ponape", TZSTR_580},
	{"Pacific/Port_Moresby", TZSTR_581},
	{"Pacific/Rarotonga", TZSTR_582},
	{"Pacific/Saipan", TZSTR_583},
	{"Pacific/Samoa", TZSTR_584},
	{"Pacific/Tahiti", TZSTR_585},
	{"Pacific/Tarawa", TZSTR_586},
	{"Pacific/Tongatapu", TZSTR_587},
	{"Pacific/Truk", TZSTR_588},
	{"Pacific/Wake", TZSTR_589},
	{"Pacific/Wallis", TZSTR_590},
	{"Pacific/Yap", TZSTR_591},
	{"Poland", TZSTR_592},
	{"Portugal", TZSTR_593},
	{"ROC", TZSTR_594},
	{"ROK", TZSTR_595},
	{"SST", TZSTR_596},
	{"Singapore", TZSTR_597},
	{"SystemV/AST4", TZSTR_598},
	{"SystemV/AST4ADT", TZSTR_599},
	{"SystemV/CST6", TZSTR_600},
	{"SystemV/CST6CDT", TZSTR_601},
	{"SystemV/EST5", TZSTR_602},
	{"SystemV/EST5EDT", TZSTR_603},
	{"SystemV/HST10", TZSTR_604},
	{"SystemV/MST7", TZSTR_605},
	{"SystemV/MST7MDT", TZSTR_606},
	{"SystemV/PST8", TZSTR_607},
	{"SystemV/PST8PDT", TZSTR_608},
	{"SystemV/YST9", TZSTR_609},
	{"SystemV/YST9YDT", TZSTR_610},
	{"Turkey", TZSTR_611},
	{"UCT", TZSTR_612},
	{"US/Alaska", TZSTR_613},
	{"US/Aleutian", TZSTR_614},
	{"US/Arizona", TZSTR_615},
	{"US/Central", TZSTR_616},
	{"US/East-Indiana", TZSTR_617},
	{"US/Eastern", TZSTR_618},
	{"US/Hawaii", TZSTR_619},
	{"US/Indiana-Starke", TZSTR_620},
	{"US/Michigan", TZSTR_621},
	{"US/Mountain", TZSTR_622},
	{"US/Pacific", TZSTR_623},
	{"US/Pacific-New", TZSTR_624},
	{"US/Samoa", TZSTR_625},
	{"UTC", TZSTR_626},
	{"Universal", TZSTR_627},
	{"VST", TZSTR_628},
	{"W-SU", TZSTR_629},
	{"WET", TZSTR_630},
	{"Zulu", TZSTR_631}
};
